/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.logger.filelogger

import android.os.Handler
import android.os.HandlerThread
import com.live.clientme.android.logger.LoggerSeverity
import com.live.clientme.android.logger.filelogger.LogWriter.WriteHandler
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

/**
 *
 * Log content format: epoch timestamp, ISO8601 timestamp (human-readable), log level, tag, log message.
 */

class DiskLogger private constructor(builder: Builder) {
    private val date: Date
    private val dateFormat: SimpleDateFormat
    private val logWriter: LogWriter
    private val tag: String?

    init {
        date = builder.date!!
        dateFormat = builder.dateFormat!!
        logWriter = builder.logWriter!!
        tag = builder.tag
    }

    fun log(priority: Int, tag: String?, message: String) {
        val formattedTag = formatTag(tag)
        date.time = System.currentTimeMillis()

        val builder = date.time.toString() +
                SEPARATOR +
                dateFormat.format(date) +
                SEPARATOR +
                logLevel(priority) +
                SEPARATOR +
                formattedTag +
                SEPARATOR +
                message +
                NEW_LINE
        logWriter.log(priority, formattedTag, builder)
    }

    private fun formatTag(tag: String?): String? {
        return if (!tag.isNullOrEmpty() && this.tag != tag) {
            this.tag + "-" + tag
        } else this.tag
    }

    class Builder {
        var date: Date? = null
        var dateFormat: SimpleDateFormat? = null
        var logWriter: LogWriter? = null
        var tag: String? = "LOGGER"
        var file: File? = null
        fun file(file: File?): Builder {
            this.file = file
            return this
        }

        fun date(date: Date?): Builder {
            this.date = date
            return this
        }

        fun dateFormat(format: SimpleDateFormat?): Builder {
            dateFormat = format
            return this
        }

        fun tag(tag: String?): Builder {
            this.tag = tag
            return this
        }

        fun build(): DiskLogger {
            if (date == null) {
                date = Date()
            }
            if (dateFormat == null) {
                dateFormat = SimpleDateFormat("yyyy.MM.dd HH:mm:ss.SSS", Locale.UK)
            }
            if (logWriter == null) {
                val folder = file!!.absolutePath + File.separatorChar + "logger"
                val ht = HandlerThread("AndroidFileLogger.$folder")
                ht.start()
                val handler: Handler = WriteHandler(ht.looper, folder, MAX_BYTES, MAX_COUNT)
                logWriter = LogWriter(handler)
            }
            return DiskLogger(this)
        }

        companion object {
            private const val MAX_BYTES = 500 * 1024 // 500K averages to a 4000 lines per file
            private const val MAX_COUNT = 2 //max no of files
        }
    }

    companion object {
        private val NEW_LINE = System.getProperty("line.separator")
        private const val SEPARATOR = ","
        fun newBuilder(file: File?): Builder {
            return Builder().file(file)
        }
    }

    private fun logLevel(value: Int): String {
        return when (value) {
            LoggerSeverity.VERBOSE -> "VERBOSE"
            LoggerSeverity.DEBUG -> "DEBUG"
            LoggerSeverity.INFO -> "INFO"
            LoggerSeverity.WARN -> "WARN"
            LoggerSeverity.ERROR -> "ERROR"
            LoggerSeverity.TRACE -> "TRACE"
            else -> "UNKNOWN"
        }
    }
}