/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.logger

import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import com.live.clientme.android.logger.LoggerSeverity.ERROR
import com.live.clientme.android.logger.LoggerSeverity.INFO
import com.live.clientme.android.logger.LoggerSeverity.TRACE
import com.live.clientme.android.logger.LoggerSeverity.VERBOSE
import com.live.clientme.android.logger.LoggerSeverity.WARN
import com.live.clientme.android.logger.apilogger.ApiLoggerRequest
import com.live.clientme.android.logger.apilogger.LoggingApiBuilder
import com.live.clientme.android.logger.apilogger.LoggingService
import kotlinx.coroutines.*
import java.util.*
import kotlin.collections.HashMap

class APILogger(private val context: Context) : BaseLogger {
    private val apiBuilder = LoggingApiBuilder.getInstance()
    private val job = Job()
    private val ioScope = CoroutineScope(Dispatchers.IO + job)

    override fun d(
        msg: String?,
        method: String?,
        className: String?,
        stacktrace: String,
        extras: HashMap<String, String>?
    ) {
        sendLogToServer(TRACE, msg, method, className, stacktrace, extras)
    }

    override fun e(
        msg: String?,
        method: String?,
        className: String?,
        stacktrace: String,
        extras: HashMap<String, String>?
    ) {
        sendLogToServer(ERROR, msg, method, className, stacktrace, extras)
    }

    override fun i(
        msg: String?,
        method: String?,
        className: String?,
        stacktrace: String,
        extras: HashMap<String, String>?
    ) {
        sendLogToServer(INFO, msg, method, className, stacktrace, extras)
    }

    override fun v(
        msg: String?,
        method: String?,
        className: String?,
        stacktrace: String,
        extras: HashMap<String, String>?
    ) {
        sendLogToServer(VERBOSE, msg, method, className, stacktrace, extras)
    }

    override fun w(
        msg: String?,
        method: String?,
        className: String?,
        stacktrace: String,
        extras: HashMap<String, String>?
    ) {
        sendLogToServer(WARN, msg, method, className, stacktrace, extras)
    }

    private fun sendLogToServer(
        severity: Int,
        msg: String?,
        method: String?,
        className: String?,
        stacktrace: String?,
        extras: HashMap<String, String>?
    ) {
        val logRequest = getLogRequest(severity, msg, method, className, stacktrace, extras)
        ioScope.launch {
            withContext(Dispatchers.IO) {
                try {
                    apiBuilder.getService(LoggingService::class.java)
                        .sendLogs(LOG_URL, logRequest)
                } catch (ex: Throwable) {
                    ex.printStackTrace()
                }
            }
        }

    }

    private fun getLogRequest(
        severity: Int,
        msg: String?,
        method: String?,
        className: String?,
        stacktrace: String?,
        extras: HashMap<String, String>?
    ): ApiLoggerRequest {
        val manager = context.packageManager
        val info = manager.getPackageInfo(
            context.packageName,
            PackageManager.GET_ACTIVITIES
        )
        val additionalProperty: HashMap<String, String> = HashMap()
        var count = 1
        extras?.forEach {
            additionalProperty["${ADDITIONAL_PROP}${count}"] = it.value
            count = count.plus(1)
        }
        additionalProperty["${ADDITIONAL_PROP}${count}"] = Build.MODEL
        return ApiLoggerRequest(
            0,
            DEVICE_MODEL,
            method,
            severity,
            additionalProperty,
            className,
            info.versionName
        )
    }

    companion object {
        const val LOG_URL = "${BuildConfig.LOG_BASE_URL}api/Logging/log"
        const val ADDITIONAL_PROP = "additionalProp"
        const val DEVICE_MODEL = "ANDROID"
    }

}