/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program ("Live Enterprise Employee Experience Interaction Suite"),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.logger

import android.content.Context
import android.os.Build
import java.util.regex.Pattern

object Logger {

    //To remove any anonymous class suffixes
    private val ANONYMOUS_CLASS = Pattern.compile("(\\$\\d+)+$")
    private const val MAX_TAG_LENGTH = 23

    private lateinit var loggerInternal: BaseLogger
    var sessionId: String? = null

    fun initialize(context: Context, type: Int) {
        loggerInternal = LoggerFactory().getLogger(context, type)
    }

    private fun createStackElementTag(element: StackTraceElement): String {
        var className = element.className.substringAfterLast('.')
        val m = ANONYMOUS_CLASS.matcher(className)
        if (m.find()) {
            className = m.replaceAll("")
        }
        return if (className.length <= MAX_TAG_LENGTH || Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            className
        } else {
            className.substring(0, MAX_TAG_LENGTH)
        }
    }

    private val classesToIgnore = listOf(
        Logger::class.java.name,
    )

    fun d(msg: String, extras: HashMap<String, String>? = null) {
        val stackInfo = getStackInfo()
        loggerInternal.d(
            msg = msg,
            className = stackInfo.className,
            method = stackInfo.method,
            extras = extras
        )
    }

    fun e(exception: Throwable, extras: HashMap<String, String>? = null) {
        val stackInfo = getStackInfo(exception)
        loggerInternal.e(
            exception.message,
            className = stackInfo.className,
            method = stackInfo.method,
            stacktrace = stackInfo.stackTrace,
            extras = extras
        )
    }

    fun e(msg: String, extras: HashMap<String, String>? = null) {
        val stackInfo = getStackInfo()
        loggerInternal.e(
            msg = msg,
            className = stackInfo.className,
            method = stackInfo.method,
            stacktrace = stackInfo.stackTrace,
            extras = extras
        )
    }

    fun i(msg: String, extras: HashMap<String, String>? = null) {
        val stackInfo = getStackInfo()
        loggerInternal.i(
            msg = msg,
            className = stackInfo.className,
            method = stackInfo.method,
            extras = extras
        )
    }

    fun v(msg: String, extras: HashMap<String, String>? = null) {
        val stackInfo = getStackInfo()
        loggerInternal.v(
            msg = msg,
            className = stackInfo.className,
            method = stackInfo.method,
            extras = extras
        )
    }

    fun w(msg: String, extras: HashMap<String, String>? = null) {
        val stackInfo = getStackInfo()
        loggerInternal.w(
            msg = msg,
            className = stackInfo.className,
            method = stackInfo.method,
            stacktrace = stackInfo.stackTrace,
            extras = extras
        )
    }

    private fun getStackInfo(exception: Throwable? = null): StackInfo {
        val stackTrace = exception?.stackTrace ?: Throwable().stackTrace

        var trace = stackTrace.contentDeepToString()
        var className = ""
        var methodName = ""

        if (stackTrace.isNotEmpty()) {
            val stackElement = stackTrace.first { it.className !in classesToIgnore }
            trace = stackTrace.filter { it.className !in classesToIgnore }
                .toString().replace(",", "\n")
            className = stackElement.let(::createStackElementTag)
            methodName = stackElement.methodName
        }
        return StackInfo(
            className = className,
            method = methodName,
            stackTrace = trace
        )
    }

    data class StackInfo(val className: String, val method: String, val stackTrace: String)
}