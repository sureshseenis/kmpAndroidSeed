/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.logger.apilogger

import com.live.clientme.android.logger.BuildConfig
import com.live.clientme.android.logger.LoggerToken
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

/**
 *
 * This class is not a thread safe.
 * Avoid creating multiple instance of this class within different threads
 */
class LoggingApiBuilder {

    private var retrofitBuilder: Retrofit.Builder = Retrofit.Builder()
        .addConverterFactory(GsonConverterFactory.create())
        .baseUrl(BuildConfig.LOG_BASE_URL)
    private val httpClientBuilder = OkHttpClient.Builder()
    private var retrofit: Retrofit

    private var requestInterceptor: Interceptor = Interceptor {
        var request = it.request()
        val requestBuilder = request.newBuilder()
        requestBuilder.addHeader("Authorization", "Bearer " + LoggerToken.accessToken)
        request = requestBuilder.build()
        it.proceed(request)
    }

    init {
        retrofit = retrofitBuilder.build()
    }

    fun addInterceptor(interceptor: Interceptor) {
        httpClientBuilder.addInterceptor(interceptor)
        retrofitBuilder.client(httpClientBuilder.build())
        retrofit = retrofitBuilder.build()
    }

    fun removeInterceptors() {
        httpClientBuilder.interceptors().clear()
    }

    fun <T> getService(clazz: Class<T>): T {
        return retrofit.create(clazz)
    }

    fun buildClient() {
        retrofitBuilder.client(httpClientBuilder.build())
        retrofit = retrofitBuilder.build()
    }

    companion object {
        private var INSTANCE: LoggingApiBuilder? = null
        private val httpClientBuilder = OkHttpClient.Builder()
        private var requestInterceptor: Interceptor = Interceptor {
            var request = it.request()
            val requestBuilder = request.newBuilder()
            requestBuilder.addHeader("Authorization", "Bearer " + LoggerToken.accessToken)
            request = requestBuilder.build()
            it.proceed(request)
        }

        fun getInstance(): LoggingApiBuilder {
            if (INSTANCE == null) {
                INSTANCE = LoggingApiBuilder()
                INSTANCE?.retrofitBuilder?.baseUrl(BuildConfig.LOG_BASE_URL)
                httpClientBuilder.addInterceptor(requestInterceptor)
                INSTANCE?.buildClient()
            }
            return INSTANCE!!
        }
    }
}