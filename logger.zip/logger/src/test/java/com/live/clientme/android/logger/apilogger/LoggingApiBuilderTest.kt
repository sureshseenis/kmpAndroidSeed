/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.logger.apilogger

import android.content.Context
import com.live.clientme.android.logger.BuildConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import okhttp3.Interceptor
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.MockitoAnnotations
import org.mockito.junit.MockitoJUnitRunner
import org.mockito.kotlin.any
import org.mockito.kotlin.times
import org.mockito.kotlin.verify

@RunWith(MockitoJUnitRunner::class)
class LoggingApiBuilderTest {

    @Mock
    lateinit var context: Context

    @Mock
    lateinit var interceptor: Interceptor

    @Mock
    lateinit var apiBuilder: LoggingApiBuilder

    lateinit var scope: CoroutineScope

    @Before
    fun setup() {
        MockitoAnnotations.openMocks(this)
        scope = CoroutineScope(Dispatchers.IO + Job())
        apiBuilder = LoggingApiBuilder()

    }

    @Test
    fun test_interceptor() {
        scope.launch {
            apiBuilder.addInterceptor(interceptor)
            val service = apiBuilder.getService(LoggingService::class.java)
            service.sendLogs(BuildConfig.LOG_BASE_URL, ApiLoggerRequest())
            verify(interceptor, times(1)).intercept(any())
        }
    }
}