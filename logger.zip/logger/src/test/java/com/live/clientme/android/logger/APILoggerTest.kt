/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.logger

import android.content.Context
import com.live.clientme.android.logger.apilogger.LoggingApiBuilder
import com.live.clientme.android.logger.apilogger.LoggingService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.MockitoAnnotations
import org.mockito.Spy
import org.mockito.junit.MockitoJUnitRunner
import org.mockito.kotlin.any

@RunWith(MockitoJUnitRunner::class)
class APILoggerTest {

    @Mock
    lateinit var context: Context

    @Mock
    lateinit var apiBuilder: LoggingApiBuilder

    @Spy
    lateinit var loggingService: LoggingService

    lateinit var scope: CoroutineScope
    lateinit var apiLogger: APILogger

    @Before
    fun setup() {
        MockitoAnnotations.openMocks(this)
        scope = CoroutineScope(Dispatchers.IO + Job())
        apiBuilder = LoggingApiBuilder()
        apiLogger = APILogger(context)
    }

    @Test
    fun test_log_debug_api() {
        scope.launch {
            val extras = HashMap<String, String>()
            Mockito.doReturn(loggingService).`when`(apiBuilder)
                .getService(LoggingService::class.java)
            apiLogger.d("test_msg", "test_method", "test_class", "test_stack", extras)
            Mockito.verify(loggingService, Mockito.times(1)).sendLogs(any(), any())
        }
    }

    @Test
    fun test_log_error_api() {
        scope.launch {
            val extras = HashMap<String, String>()
            Mockito.doReturn(loggingService).`when`(apiBuilder)
                .getService(LoggingService::class.java)
            apiLogger.e("test_msg", "test_method", "test_class", "test_stack", extras)
            Mockito.verify(loggingService, Mockito.times(1)).sendLogs(any(), any())
        }
    }

    @Test
    fun test_log_warn_api() {
        scope.launch {
            val extras = HashMap<String, String>()
            Mockito.doReturn(loggingService).`when`(apiBuilder)
                .getService(LoggingService::class.java)
            apiLogger.w("test_msg", "test_method", "test_class", "test_stack", extras)
            Mockito.verify(loggingService, Mockito.times(1)).sendLogs(any(), any())
        }
    }

    @Test
    fun test_log_info_api() {
        scope.launch {
            val extras = HashMap<String, String>()
            Mockito.doReturn(loggingService).`when`(apiBuilder)
                .getService(LoggingService::class.java)
            apiLogger.i("test_msg", "test_method", "test_class", "test_stack", extras)
            Mockito.verify(loggingService, Mockito.times(1)).sendLogs(any(), any())
        }
    }

    @Test
    fun test_log_verbose_api() {
        scope.launch {
            val extras = HashMap<String, String>()
            Mockito.doReturn(loggingService).`when`(apiBuilder)
                .getService(LoggingService::class.java)
            apiLogger.v("test_msg", "test_method", "test_class", "test_stack", extras)
            Mockito.verify(loggingService, Mockito.times(1)).sendLogs(any(), any())
        }
    }

}