/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.logger

import kotlinx.coroutines.ExperimentalCoroutinesApi
import org.junit.Assert
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.MockitoAnnotations
import org.mockito.junit.MockitoJUnitRunner

@ExperimentalCoroutinesApi
@RunWith(MockitoJUnitRunner::class)
class DBLoggerTest {

    @Mock
    lateinit var logger: BaseLogger

    private val hashExtra = hashMapOf<String, String>()

    @Before
    fun setUp() {
        MockitoAnnotations.openMocks(this)
        with(hashExtra) { put("code", "value") }
        logger = DBLogger()
    }

    @Test
    fun test_d_non_null() {
        val result = logger.d("msg", "method", "class", "trace", hashExtra)
        Assert.assertNotNull(result)
    }

    @Test
    fun test_e_non_null() {
        val result = logger.e("msg", "method", "class", "trace", hashExtra)
        Assert.assertNotNull(result)
    }

    @Test
    fun test_i_non_null() {
        val result = logger.i("msg", "method", "class", "trace", hashExtra)
        Assert.assertNotNull(result)
    }

    @Test
    fun test_v_non_null() {
        val result = logger.v("msg", "method", "class", "trace", hashExtra)
        Assert.assertNotNull(result)
    }

    @Test
    fun test_w_non_null() {
        val result = logger.w("msg", "method", "class", "trace", hashExtra)
        Assert.assertNotNull(result)
    }
}