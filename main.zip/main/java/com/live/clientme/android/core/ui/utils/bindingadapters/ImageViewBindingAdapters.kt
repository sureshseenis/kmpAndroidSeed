/*
 * © 2023 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.ui.utils.bindingadapters

import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.net.Uri
import android.util.Base64
import android.util.TypedValue
import android.widget.ImageView
import androidx.annotation.DrawableRes
import androidx.core.widget.ImageViewCompat
import androidx.databinding.BindingAdapter
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.bitmap.CenterCrop
import com.bumptech.glide.load.resource.bitmap.RoundedCorners
import com.bumptech.glide.request.RequestOptions
import com.live.clientme.android.core.ui.utils.extensions.getDrawable

@BindingAdapter("source")
fun source(imageView: ImageView, @DrawableRes resource: Int) {
    Glide.with(imageView.context)
        .load(resource)
        .into(imageView)
}

@BindingAdapter("source")
fun source(imageView: ImageView, resource: Bitmap?) {
    if (resource == null) {
        return
    }
    Glide.with(imageView.context)
        .load(resource)
        .into(imageView)
}

/**
 * Finds a resource drawable by the resource name and binds it.
 * If the resource not found, then identifies it as a url and try to load it
 */
@BindingAdapter("source")
fun source(imageView: ImageView, resource: String?) {
    if (resource == null) {
        return
    }
    val context = imageView.context
    val drawable = context.getDrawable(resource)
    if (drawable == 0) {
        Glide.with(context).load(resource).into(imageView)
    } else {
        Glide.with(context).load(drawable).into(imageView)
    }

}

@BindingAdapter("tintSource")
fun tintSource(imageView: ImageView, resource: String?) {
    if (resource == null) {
        return
    }
    val context = imageView.context
    val drawable = context.getDrawable(resource)
    if (drawable == 0) {
        Glide.with(context).load(resource).into(imageView)
    } else {
        Glide.with(context).load(drawable).into(imageView)
        ImageViewCompat.setImageTintList(imageView, ColorStateList.valueOf(Color.BLACK))
    }
}

/**
 * Finds a resource drawable by the resource name and binds it.
 * If the resource not found, then identifies it as a url and try to load it
 */
@BindingAdapter("source", "placeholder")
fun source(imageView: ImageView, resource: String?, sourcePlaceHolder: Drawable) {
    if (resource == null) {
        return
    }
    val context = imageView.context
    val drawable = context.getDrawable(resource)
    if (drawable == 0) {
        Glide.with(context).load(resource)
            .error(Glide.with(imageView.context).load(sourcePlaceHolder))
            .into(imageView)
    } else {
        Glide.with(context).load(drawable)
            .error(Glide.with(imageView.context).load(sourcePlaceHolder))
            .into(imageView)
    }

}

@BindingAdapter("uri", "placeholder")
fun source(imageView: ImageView, uri: Uri?, sourcePlaceHolder: Drawable) {
    val context = imageView.context
    val reqManager = Glide.with(context)
    val errorBuilder = reqManager.load(sourcePlaceHolder)
    reqManager
        .load(uri)
        .error(errorBuilder)
        .into(imageView)
}

@BindingAdapter("roundSrc")
fun roundSrc(imageView: ImageView, resource: String?) {
    if (resource == null) {
        return
    }
    val context = imageView.context
    val drawable = context.getDrawable(resource)
    if (drawable == 0) {
        Glide.with(context).load(resource).apply(RequestOptions.circleCropTransform())
            .into(imageView)
    } else {
        Glide.with(context).load(drawable).apply(RequestOptions.circleCropTransform())
            .into(imageView)
    }
}


/**
 * @param roundingRadius float value in Dp
 */
@BindingAdapter("roundedCornerSrc", "roundingRadius")
fun roundedCornerSrc(imageView: ImageView, resource: String?, roundingRadius: Float) {
    if (resource == null) {
        return
    }
    val context = imageView.context
    val drawable = context.getDrawable(resource)
    var requestOptions = RequestOptions()
    requestOptions = requestOptions.transform(
        CenterCrop(),
        RoundedCorners(
            TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP,
                roundingRadius,
                context.resources.displayMetrics
            ).toInt()
        )
    )

    if (drawable == 0) {
        Glide.with(context).load(resource)
            .apply(
                requestOptions
            )
            .into(imageView)
    } else {
        Glide.with(context).load(drawable)
            .apply(
                requestOptions
            )
            .into(imageView)
    }
}

@BindingAdapter("encodedSource")
fun encodedSource(imageView: ImageView, resource: String?) {
    if (resource == null) {
        return
    }
    val context = imageView.context
    val encodeByte: ByteArray = Base64.decode(resource, Base64.DEFAULT)
    val bitmap = BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.size)
    Glide.with(context).load(bitmap).apply(RequestOptions.circleCropTransform())
        .into(imageView)
}

@BindingAdapter("byteSource")
fun byteSource(imageView: ImageView, encodeByte: ByteArray?) {
    if (encodeByte == null) {
        return
    }
    val context = imageView.context
    val bitmap = BitmapFactory.decodeByteArray(encodeByte, 0, encodeByte.size)
    Glide.with(context).load(bitmap).apply(RequestOptions.circleCropTransform())
        .into(imageView)
}
