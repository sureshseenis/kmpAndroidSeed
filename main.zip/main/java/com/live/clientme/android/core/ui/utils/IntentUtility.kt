/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.ui.utils

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri

object IntentUtility {
    fun openTeams(context: Context) {
        val packageName = "com.microsoft.teams"
        val pm = context.packageManager
        val intent = pm.getLaunchIntentForPackage(packageName)
        intent?.addCategory(Intent.CATEGORY_LAUNCHER)
        if (intent != null) {
            try {
                context.startActivity(intent)
            } catch (ex: ActivityNotFoundException) {
                launchPlayStoreWithAppPackage(context, packageName)
            }
        } else {
            launchPlayStoreWithAppPackage(context, packageName)
        }
    }

    fun openOutLookUseEmail(context: Context, email: String) {
        try {
            val intent = Intent(Intent.ACTION_SEND)
            intent.type = "vnd.android.cursor.item/email"
            intent.putExtra(Intent.EXTRA_EMAIL, arrayOf(email))
            intent.putExtra(Intent.EXTRA_SUBJECT, "")
            context.startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            launchPlayStoreWithAppPackage(context, OUTLOOK_PACKAGE)
        } catch (e: Exception) {
            launchPlayStoreWithAppPackage(context, OUTLOOK_PACKAGE)
        } catch (t: Throwable) {
            launchPlayStoreWithAppPackage(context, OUTLOOK_PACKAGE)
        }
    }

    fun openTeamsUseEmail(context: Context, email: String) {
        val isTeamsFound = context.packageManager.getLaunchIntentForPackage(TEAMS_PACKAGE)
        if (isTeamsFound != null) {
            val sendIntent = Intent(Intent.ACTION_VIEW, Uri.parse("$OUT_LOOK_EMAIL$email"))
            context.startActivity(sendIntent)
        } else {
            launchPlayStoreWithAppPackage(context, TEAMS_PACKAGE)
        }
    }

    private fun launchPlayStoreWithAppPackage(context: Context, packageName: String) {
        val intent = Intent(Intent.ACTION_VIEW)
        intent.data = Uri.parse("https://play.google.com/store/apps/details?id=$packageName")
        context.startActivity(intent)
    }

    fun openExternalBrowser(context: Context, link: String) {
        val intent = Intent(Intent.ACTION_VIEW)
        intent.data = Uri.parse(link)
        context.startActivity(intent)
    }

    fun addEventToCalendar(context: Context, intent: Intent) {
        context.startActivity(intent)
    }


    private const val OUTLOOK_PACKAGE = "com.microsoft.office.outlook"
    private const val TEAMS_PACKAGE = "com.microsoft.teams"
    private const val PLAY_STORE_URL = "https://play.google.com/store/apps/details?id="
    private const val OUT_LOOK_EMAIL = "https://teams.microsoft.com/l/chat/0/0?users="
}