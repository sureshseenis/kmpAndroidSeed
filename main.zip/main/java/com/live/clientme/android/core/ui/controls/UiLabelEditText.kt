/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.ui.controls

import android.content.Context
import android.util.AttributeSet
import android.util.TypedValue
import android.view.LayoutInflater
import android.widget.LinearLayout
import androidx.core.widget.doOnTextChanged
import com.live.clientme.android.core.R
import com.live.clientme.android.core.databinding.UiLabelEdittextBinding


class UiLabelEditText : LinearLayout {

    private lateinit var binding: UiLabelEdittextBinding

    constructor(context: Context?) : super(context) {
        init(context, null)
    }

    constructor(context: Context?, attrs: AttributeSet?) : super(context, attrs) {
        init(context, attrs)
    }

    constructor(context: Context?, attrs: AttributeSet?, defStyleAttr: Int)
            : super(context, attrs, defStyleAttr) {
        init(context, attrs)
    }

    fun setInputText(text: String?) {
        binding.inputEditText.setText(text)
    }

    fun setInputHint(hint: String?) {
        binding.inputEditText.hint = hint
    }

    fun getInputText(): String {
        return binding.inputEditText.text.toString()
    }

    fun setOnTextChanged(listener: (String) -> Unit) {
        binding.inputEditText.doOnTextChanged { text, _, _, _ ->
            listener.invoke(text.toString())
        }
    }

    private fun init(context: Context?, attrs: AttributeSet?) {
        val inflater = LayoutInflater.from(context)
        binding = UiLabelEdittextBinding.inflate(inflater, this, true)
        val attr =
            getContext().theme.obtainStyledAttributes(attrs, R.styleable.UiLabelEditText, 0, 0)
        try {

            val labelText = attr.getText(R.styleable.UiLabelEditText_labelText)
            binding.labelTextView.text = labelText

            val labelHint = attr.getText(R.styleable.UiLabelEditText_inputHint)
            binding.inputEditText.hint = labelHint

            val labelTextSize =
                attr.getDimensionPixelSize(R.styleable.UiLabelEditText_labelTextSize, -1)

            if (labelTextSize != -1) {
                binding.labelTextView.setTextSize(
                    TypedValue.COMPLEX_UNIT_PX,
                    labelTextSize.toFloat()
                )
            }

            val inputTextSize =
                attr.getDimensionPixelSize(R.styleable.UiLabelEditText_inputTextSize, -1)

            if (inputTextSize != -1) {
                binding.inputEditText.setTextSize(
                    TypedValue.COMPLEX_UNIT_PX,
                    inputTextSize.toFloat()
                )
            }

            val labelTextColor =
                attr.getColor(R.styleable.UiLabelEditText_labelTextColor, -1)

            if (labelTextColor != -1) {
                binding.labelTextView.setTextColor(labelTextColor)
            }

            val inputTextColor =
                attr.getColor(R.styleable.UiLabelEditText_inputTextColor, -1)

            if (inputTextColor != -1) {
                binding.inputEditText.setTextColor(inputTextColor)
            }

            val labelBackground = attr.getColor(R.styleable.UiLabelEditText_labelTint, -1)
            if (labelBackground != -1) {
                binding.labelTextView.background.setTint(labelBackground)
            }

        } finally {
            attr.recycle()
        }
    }
}