/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program ("Live Enterprise Employee Experience Interaction Suite"),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.services

import com.google.gson.Gson
import com.live.clientme.android.core.services.models.BaseResponse
import com.live.clientme.android.core.services.models.ErrorResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.IOException
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

@Deprecated(message = "Use retrofit's synchronous method itself")
suspend inline fun <reified In : BaseResponse> Call<In?>.get(): In? {
    return suspendCoroutine {

        this.enqueue(object : Callback<In?> {
            override fun onFailure(call: Call<In?>, t: Throwable) {
                it.resume(onFailure(throwableError = t))
            }

            override fun onResponse(call: Call<In?>, response: Response<In?>) {
                val value = response.body()
                if (response.isSuccessful) {
                    it.resume(value)
                } else {
                    it.resume(onFailure(value?.errorMessage))
                }
            }
        })
    }
}

inline fun <reified In : BaseResponse> onFailure(
    serviceErrorData: ErrorResponse? = null,
    throwableError: Throwable? = null
): In {
    val input = In::class.java.newInstance()
    serviceErrorData?.let {
        when (it.errorCode?.toInt() ?: 0) {
            401 -> it.errorCode = ErrorCodes.UNAUTHORIZED_ERROR
            415 -> it.errorCode = ErrorCodes.UNSUPPORTED_MEDIA_TYPE
            else -> it.errorCode = ErrorCodes.GENERIC_ERROR
        }
        input.errorMessage = it
    } ?: run {
        val throwableErrorData = ErrorResponse()
        throwableErrorData.errorCode =
            if (throwableError is IOException) ErrorCodes.IO_ERROR else ErrorCodes.GENERIC_ERROR
        throwableErrorData.message = throwableError?.message
        input.errorMessage = throwableErrorData
    }

    return input
}

/**
 * Deserialize given model into string
 *
 * Usage: val person: Person = "{\"name\":\"Bob\"}".fromJson()
 */
inline fun <reified T> String.fromJson(): T {
    return Gson().fromJson(this, T::class.java)
}

/**
 * Serialize string into given model
 *
 * Usage: val jsonString = person.toJson()
 */
inline fun <reified T> T.toJson(): String {
    return Gson().toJson(this)
}
