/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program ("Live Enterprise Employee Experience Interaction Suite"),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.domain

object ErrorCodes {

    object Base {
        const val GENERIC_ERROR = "3000"
        const val UNSUPPORTED_MEDIA_TYPE = "3001"
        const val SOFT_UPDATE_ERROR = "3002"
        const val FORCE_UPDATE_ERROR = "3003"
        const val UNAUTHORIZED_ERROR = "3004"
        const val IO_ERROR = "3005"
        const val NETWORK_ERROR = "3006"
        const val NO_DATA_ERROR = "3007"
        const val ACTION_CANCELLED = "3008"

        const val INTERNAL_SERVER_ERROR = "500"
        const val BAD_REQUEST = "400"
    }

    object Login {
        /**
         * Login method is not supported
         */
        const val UNSUPPORTED = "4000"
    }

    object MessageResponse {
        const val SUCCESS = "5000"
    }
}