/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.ui.dialog

import android.content.Context
import android.view.LayoutInflater
import android.widget.LinearLayout
import androidx.databinding.DataBindingUtil
import com.live.clientme.android.core.R
import com.live.clientme.android.core.databinding.MaterialEdittextBinding


class DynamicActionDialog(context: Context, modelList: ArrayList<DynamicActionModel>) :
    MaterialDialog(context) {

    init {

        val inflater = LayoutInflater.from(context)

        val viewGroup = LinearLayout(context)
        viewGroup.orientation = LinearLayout.VERTICAL

        for (model in modelList) {
            val binding: MaterialEdittextBinding = DataBindingUtil.inflate(
                inflater, R.layout.material_edittext, null, false
            )
            binding.model = model
            viewGroup.addView(binding.root)
        }
        setContentView(viewGroup)
    }

    data class DynamicActionModel(var name: String, var hint: String, var text: String)
}