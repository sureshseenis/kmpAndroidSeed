/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.ui

import android.view.View
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.navigation.findNavController
import com.live.clientme.android.core.domain.BaseResult
import com.live.clientme.android.core.domain.ErrorResult
import com.live.clientme.android.core.ui.event.Event
import com.live.clientme.android.core.ui.event.LiveEvent
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.launch

/**
 * Parent class for ViewModels.
 * Extend with this class when you are using AndroidViewModels.
 * It offers method execution via coroutine for async operations.
 */
open class BaseViewModel : ViewModel() {

    /**
     * Launches a coroutine in the provided dispatcher
     * @param defaultDispatcher the CoroutineDispatcher in which the coroutine should run on
     */
    protected fun launch(defaultDispatcher: CoroutineDispatcher, action: suspend () -> Unit) {
        viewModelScope.launch(defaultDispatcher) {
            action.invoke()
        }
    }

    private fun errorToEvent(errorResult: ErrorResult?, defaultEvent: String): Event<String?> {
        val eventKey = errorResult?.errorCode ?: defaultEvent
        return Event.create(eventKey, errorResult?.errorMsg)
    }

    fun LiveEvent.postEvent(result: BaseResult) {
        if (result.success) {
            postEvent(CoreEvents.SUCCESS)
        } else {
            val error = errorToEvent(result.errorResult, CoreEvents.FAILURE)
            postValue(error)
        }
    }

    fun onBackPressed(view: View) {
        view.findNavController().navigateUp()
    }
}