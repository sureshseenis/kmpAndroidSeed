/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.ui.event

import android.app.Activity
import android.content.Context
import com.infosys.telemetry.EventData
import com.infosys.telemetry.TelemetryFactory
import com.infosys.telemetry.TelemetryService

class TelemetryEventProvider {

    private var mTelemetryService: TelemetryService<EventData<Any>>? = null

    /**
     * Initializes the telemetry event service with session values
     *
     * @param context Context
     * @param empMailID User Email ID.
     * @param token Session Token
     */
    fun init(context: Context, empMailID: String, token: String) {
        var employeeEmailID = empMailID
        if (employeeEmailID.isNotEmpty()) {
            try {
                employeeEmailID = employeeEmailID.split("@".toRegex()).toTypedArray()[0]
                mTelemetryService = TelemetryFactory.getTelemetry(
                    context,
                    token
                ) as TelemetryService<EventData<Any>>?
                mTelemetryService?.setUserId(employeeEmailID)
            } catch (e: Exception) {
                println(
                    "Telemetry Initialization error: ${e.message}"
                )
            }
        }
    }

    /**
     * Logs a telemetry event
     *
     * @param activity The Activity from where the event is send
     * @param eventType Type of event
     * @param eventKey Key of the event
     * @param eventValue Value of the event
     * @param realTime True for the events that should be immediately send, otherwise false
     */
    fun logEvent(
        activity: Activity,
        eventType: String,
        eventKey: String,
        eventValue: String,
        realTime: Boolean = true
    ) {
        val eventData = TelemetryFactory.newEventData(activity.applicationContext)
        eventData.putString(eventKey, eventValue)
        mTelemetryService?.logEvent(eventType, eventData, activity, realTime)
    }
}