/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program ("Live Enterprise Employee Experience Interaction Suite"),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.ui.dialog

import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.graphics.drawable.ColorDrawable
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import com.live.clientme.android.core.R
import com.live.clientme.android.core.databinding.LayoutFeedbackConfirmBinding

object AlertDialogUtility {

    var dialogShowing = false
    const val dialogShowErrorMessage = "App update available, Please update app to get new fetchers"
    private const val TAG = "AlertDialogUtility"

    fun showAppUpdateDialog(
        context: Context, softUpdate: Boolean = false,
        pListener: DialogInterface.OnClickListener? = null,
        nListener: DialogInterface.OnClickListener? = null
    ) {
        if (dialogShowing) {
            Log.e(TAG, dialogShowErrorMessage)
            return
        }
        val msg = if (softUpdate) {
            context.getString(R.string.soft_update_message)
        } else context.getString(R.string.force_update_message)

        val dialog = AlertDialogComposer.createDialog(
            context = context,
            title = context.getString(R.string.dialog_title_error),
            message = msg,
            pText = context.getString(R.string.update),
            nText = context.getString(R.string.close),
            pListener = { dialog, which ->
                pListener?.onClick(dialog, which)
                dialog.dismiss()
            }, nListener = { dialog, which ->
                nListener?.onClick(dialog, which)
                dialog.dismiss()
            })
        showDialog(dialog)
    }

    fun showGenericErrorDialog(context: Context) {
        if (dialogShowing) {
            Log.e(TAG, dialogShowErrorMessage)
            return
        }
        val dialog = AlertDialogComposer.createMaterialDialog(
            context = context,
            title = context.getString(R.string.dialog_title_error),
            message = context.getString(R.string.server_error),
            pText = context.getString(R.string.close),
            nListener = getDefaultListener(),
            pListener = getDefaultListener()
        )
        showDialog(dialog)
    }

    fun showDialog(dialog: Dialog) {
        dialogShowing = true
        dialog.show()
    }

    private fun getDefaultListener(listener: DialogInterface.OnClickListener? = null): DialogInterface.OnClickListener {
        return DialogInterface.OnClickListener { dialog, which ->
            dialogShowing = false
            listener?.onClick(dialog, which)
            dialog.dismiss()
        }
    }

    fun showGenericDialog(
        context: Context,
        title: String,
        message: String,
        negativeButtonText: String,
        positiveButtonText: String,
        negativeButtonClickListener: DialogInterface.OnClickListener? = null,
        positiveButtonClickListener: DialogInterface.OnClickListener? = null
    ) {
        if (dialogShowing) {
            Log.e(TAG, dialogShowErrorMessage)
            return
        }
        val dialog = AlertDialogComposer.createMaterialDialog(
            context = context,
            title = title,
            message = message,
            pText = positiveButtonText,
            pListener = getDefaultListener(positiveButtonClickListener),
            nText = negativeButtonText,
            nListener = getDefaultListener(negativeButtonClickListener)
        )
        showDialog(dialog)
    }

    fun showFeedbackConfirmation(context: Context, pListener: () -> Unit) {
        val inflater = LayoutInflater.from(context)
        val binding = LayoutFeedbackConfirmBinding.inflate(inflater)
        val dialog = setCustomDialog(context, binding.root)
        binding.feedbackCloseBtn.setOnClickListener {
            dialog.dismiss()
            pListener.invoke()
            dialogShowing = false

        }
        showDialog(dialog)
    }

    private fun setCustomDialog(
        context: Context,
        contentView: View
    ): Dialog {
        val dialog = Dialog(context)
        dialog.setCancelable(false)
        dialog.setCanceledOnTouchOutside(false)
        dialog.setContentView(contentView)
        dialog.window?.setLayout(
            ViewGroup.LayoutParams.WRAP_CONTENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        dialog.window?.setBackgroundDrawable(
            ColorDrawable(
                ContextCompat.getColor(
                    context,
                    R.color.color_transparent
                )
            )
        )
        dialog.show()
        return dialog
    }

    fun showValidationDialog(
        context: Context,
        message: String,
        positiveButtonText: String,
        positiveButtonClickListener: DialogInterface.OnClickListener? = null
    ) {
        if (dialogShowing) {
            Log.e(TAG, dialogShowErrorMessage)
            return
        }
        val dialog = AlertDialogComposer.createMaterialDialog(
            context = context,
            message = message,
            pText = positiveButtonText,
            pListener = getDefaultListener(positiveButtonClickListener),
        )
        showDialog(dialog)
    }

    fun showErrorDialog(context: Context, errorMessage: String) {
        if (dialogShowing) {
            return
        }
        val dialog = AlertDialogComposer.createMaterialDialog(
            context = context,
            title = "",
            message = errorMessage,
            pText = context.getString(R.string.label_ok),
            nListener = getDefaultListener(),
            pListener = getDefaultListener()
        )
        showDialog(dialog)
    }
}
