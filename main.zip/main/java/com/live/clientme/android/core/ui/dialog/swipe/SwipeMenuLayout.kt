/*
 * © 2023 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */
package com.live.clientme.android.core.ui.dialog.swipe

import android.annotation.SuppressLint
import android.content.Context
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.View.OnTouchListener
import android.view.ViewGroup
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.constraintlayout.widget.ConstraintSet
import androidx.core.view.children
import com.live.clientme.android.core.R

class SwipeMenuLayout @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    style: Int = 0
) :
    ConstraintLayout(context, attrs, style) {

    private var actionDownValuePosition = 0.0f
    private var afterChangeDistanceValue = 0.0f
    private var newMarginValue = 0
    private var bgViewWidth = 0
    private var bgViewHalfWidth = 0

    private lateinit var backgroundView: View
    private lateinit var layoutBgParams: LayoutParams
    private lateinit var foregroundView: View
    private lateinit var layoutFgParams: LayoutParams

    private var isExpanded = false
    private var isLeftMenu = true
    private var changedMenuWidth = true
    private var bgViewWidthMeasure = true

    private var onClickViewListener: OnClickListener? = null
    private var onItemSwipeListener: OnItemSwipeListener? = null

    init {
        attrs?.let { attributeValues(context, it) }
    }

    private fun attributeValues(context: Context, attributeSet: AttributeSet) {
        context.theme.obtainStyledAttributes(attributeSet, R.styleable.SimpleSwipeMenuLayout, 0, 0)
            .let {
                isLeftMenu = false
                it.getInt(R.styleable.SimpleSwipeMenuLayout_menuSide, INT_LEFT)
                changedMenuWidth = true
                it.getBoolean(
                    R.styleable.SimpleSwipeMenuLayout_dynamicMenuWidth,
                    MENU_DEFAULT_WIDTH
                )
                it.recycle()
            }
    }

    override fun onFinishInflate() {
        super.onFinishInflate()
        if (childCount != CHILDREN_COUNT) throw Throwable(
            ERROR_CHILDREN_COUNT
        )

        backgroundView = getChildAt(FG_VIEW_INDEX)
        foregroundView = getChildAt(BG_VIEW_INDEX)

        if (id == ITEM_EMPTY_ID) throw Throwable(ERROR_MAIN_VIEW_ID)
        if (backgroundView.id == ITEM_EMPTY_ID) throw Throwable(
            ERROR_BG_VIEW_ID
        )
        if (foregroundView.id == ITEM_EMPTY_ID) throw Throwable(
            ERROR_FG_VIEW_ID
        )

        updateConstraintValues()

        layoutFgParams = foregroundView.layoutParams as LayoutParams
        layoutBgParams = backgroundView.layoutParams as LayoutParams

        if (layoutBgParams.height != BG_VIEW_HEIGHT) throw Throwable(
            ERROR_BG_HEIGHT
        )

        if (!changedMenuWidth) {
            bgViewWidth = backgroundView.layoutParams.width
            bgViewHalfWidth = bgViewWidth / 2
        }

        updateOnExpandBgViewClickEvents()

        setOnTouchListener(itemOnTouchListener())
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec)
        if (changedMenuWidth && bgViewWidthMeasure) {
            bgViewWidthMeasure = false
            measureBgViewWidth()
        }
    }

    private fun measureBgViewWidth() {
        bgViewWidth = backgroundView.measuredWidth
        bgViewHalfWidth = bgViewWidth / 2
    }

    fun apply(isExpanded: Boolean) {
        this.isExpanded = isExpanded

        updateFgViewSwipeStatus()

        if (changedMenuWidth) {
            post {
                measureBgViewWidth()
                updateFgViewSwipeStatus()
            }
        }
    }

    private fun updateOnExpandBgViewClickEvents() {
        (backgroundView as? ViewGroup)?.let { viewGroup ->
            viewGroup.children.forEach {
                it.isClickable = isExpanded
            }
        }
    }

    private fun updateConstraintValues() {
        ConstraintSet().let {
            val sideConstraintSet = if (isLeftMenu) ConstraintSet.START else ConstraintSet.END

            it.clone(this)
            it.connect(backgroundView.id, sideConstraintSet, id, sideConstraintSet)
            it.connect(
                backgroundView.id,
                ConstraintSet.TOP,
                foregroundView.id,
                ConstraintSet.TOP
            )
            it.connect(
                backgroundView.id,
                ConstraintSet.BOTTOM,
                foregroundView.id,
                ConstraintSet.BOTTOM
            )
            it.applyTo(this)
        }
    }

    private fun updateFgViewSwipeStatus() {
        if (isExpanded) expandItem() else collapseItem()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun itemOnTouchListener() = OnTouchListener { _, event ->
        when (event.action) {
            MotionEvent.ACTION_DOWN -> downAction(event.x)
            MotionEvent.ACTION_UP -> releaseAction(false)
            MotionEvent.ACTION_CANCEL -> releaseAction(true)
            MotionEvent.ACTION_MOVE -> movementUpdate(event.x)
        }
        true
    }

    private fun downAction(position: Float) {
        actionDownValuePosition = position
    }

    private fun releaseAction(loseTouch: Boolean) {
        val wasSwiping = swipeCheck()

        if (newMarginValue > bgViewHalfWidth) expandItem()
        else collapseItem()

        onItemSwipeListener?.onSwipe(isExpanded)

        if (!loseTouch && !wasSwiping) onClickViewListener?.onClick(this)
    }

    private fun expandItem() {
        isExpanded = true
        newMarginValue = bgViewWidth
        updateFgViewMargin()
        updateDistance()
        updateOnExpandBgViewClickEvents()
    }

    private fun collapseItem() {
        isExpanded = false
        newMarginValue = 0
        updateFgViewMargin()
        updateDistance()
        updateOnExpandBgViewClickEvents()
    }

    fun setOnItemSwipeListener(onSwipeListener: OnItemSwipeListener) {
        this.onItemSwipeListener = onSwipeListener
    }

    override fun setOnClickListener(onClickListener: OnClickListener?) {
        this.onClickViewListener = onClickListener
    }

    private fun updateDistance() {
        afterChangeDistanceValue = 0f
    }

    private fun movementUpdate(position: Float) {
        if (isExpanded) updateCollapseMargin(position) else updateExpandMargin(
            position
        )
        if (swipeCheck()) updateFgViewMargin()
    }

    private fun updateExpandMargin(position: Float) {
        afterChangeDistanceValue =
            if (isLeftMenu) position - actionDownValuePosition else actionDownValuePosition - position
        newMarginValue = when {
            afterChangeDistanceValue < 0 -> 0
            afterChangeDistanceValue > bgViewWidth -> bgViewWidth
            else -> afterChangeDistanceValue.toInt()
        }
    }

    private fun updateCollapseMargin(position: Float) {
        afterChangeDistanceValue =
            if (isLeftMenu) actionDownValuePosition - position else position - actionDownValuePosition
        newMarginValue = when {
            afterChangeDistanceValue < 0 -> bgViewWidth
            afterChangeDistanceValue > bgViewWidth -> 0
            else -> (bgViewWidth - afterChangeDistanceValue).toInt()
        }
    }

    private fun updateFgViewMargin() {
        layoutFgParams.leftMargin = newMarginValue * (if (isLeftMenu) 1 else -1)
        layoutFgParams.rightMargin = newMarginValue * (if (isLeftMenu) -1 else 1)
        foregroundView.requestLayout()
    }

    private fun swipeCheck(): Boolean {
        swiping = afterChangeDistanceValue > DISTANCE_TO_SWIPE_MIN_VALUE
        return swiping
    }

    companion object {
        var swiping = false
        private const val FG_VIEW_INDEX = 0
        private const val BG_VIEW_INDEX = 1
        private const val INT_LEFT = 1
        private const val DISTANCE_TO_SWIPE_MIN_VALUE = 10
        private const val CHILDREN_COUNT = 2
        private const val ITEM_EMPTY_ID = -1
        private const val BG_VIEW_HEIGHT = 0
        private const val MENU_DEFAULT_WIDTH = true
        private const val ERROR_CHILDREN_COUNT = "Error Children count"
        private const val ERROR_MAIN_VIEW_ID = "Error Main Id"
        private const val ERROR_FG_VIEW_ID = "Error Foreground ID"
        private const val ERROR_BG_VIEW_ID = "Error Background Id"
        private const val ERROR_BG_HEIGHT = "Error_Background_Height"
    }
}