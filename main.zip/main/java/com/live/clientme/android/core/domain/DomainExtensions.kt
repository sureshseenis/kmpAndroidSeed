/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program ("Live Enterprise Employee Experience Interaction Suite"),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */
package com.live.clientme.android.core.domain

import org.modelmapper.Conditions
import org.modelmapper.ModelMapper
import java.util.stream.Collectors

inline fun <reified V : Any> Any.convertTo(): V {
    val modelMapper = ModelMapper()
    modelMapper.configuration.isAmbiguityIgnored = true
    modelMapper.configuration.isSkipNullEnabled = true
    modelMapper.configuration.propertyCondition = Conditions.isNotNull()
    return modelMapper.map(this, V::class.java)
}

inline fun <V, reified T> List<V>.mapListTo(): List<T> {
    val modelMapper = ModelMapper()
    modelMapper.configuration.isAmbiguityIgnored = true
    modelMapper.configuration.isSkipNullEnabled = true
    modelMapper.configuration.propertyCondition = Conditions.isNotNull()
    return this
        .stream()
        .map<T> { element ->
            modelMapper.map(
                element,
                T::class.java
            )
        }
        .collect(Collectors.toList())
}

inline fun <V, reified T> ArrayList<V>.mapListTo(): ArrayList<T> {
    val modelMapper = ModelMapper()
    modelMapper.configuration.isAmbiguityIgnored = true
    modelMapper.configuration.isSkipNullEnabled = true
    modelMapper.configuration.propertyCondition = Conditions.isNotNull()
    return this
        .stream()
        .map<T> { element ->
            modelMapper.map(
                element,
                T::class.java
            )
        }
        .collect(Collectors.toList()) as ArrayList
}