/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.ui.dialog

import android.content.Context
import android.content.DialogInterface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.IntegerRes
import androidx.databinding.DataBindingUtil
import com.live.clientme.android.core.R
import com.live.clientme.android.core.databinding.MaterialAlertDialogBinding

/**
 *
 * A simple material dialog
 */
open class MaterialDialog(context: Context) : BaseDialog(context), DialogInterface {

    private var dialogModel = AlertDialogModel()

    private var binding: MaterialAlertDialogBinding = DataBindingUtil.inflate(
        LayoutInflater.from(context),
        R.layout.material_alert_dialog,
        null,
        false
    )

    init {
        super.setContentView(binding.root)
    }

    override fun show() {
        binding.dataModel = dialogModel
        super.show()
    }

    override fun setTitle(titleId: Int) {
        setTitle(context.resources.getString(titleId))
    }

    override fun setTitle(title: CharSequence?) {
        dialogModel.title = title.toString()
    }

    fun setMessage(message: String?) {
        dialogModel.message = message
    }

    fun setPositiveButton(
        positiveText: String?, positiveListener: DialogInterface.OnClickListener?
    ) {
        dialogModel.positiveBtnText = positiveText
        if (positiveListener == null) dialogModel.positiveAction = {
            dismiss()
        } else {
            dialogModel.positiveAction = {
                positiveListener.onClick(this, DialogInterface.BUTTON_POSITIVE)
            }
        }
    }

    fun setNegativeButton(
        negativeText: String?, negativeListener: DialogInterface.OnClickListener?
    ) {
        dialogModel.negativeBtnText = negativeText
        if (negativeListener == null) dialogModel.negativeAction = {
            dismiss()
        } else {
            dialogModel.negativeAction = {
                negativeListener.onClick(this, DialogInterface.BUTTON_NEGATIVE)
            }
        }
    }


    override fun setContentView(@IntegerRes layoutResID: Int) {
        val view = LayoutInflater.from(context).inflate(layoutResID, null)
        setContentView(view)
    }

    override fun setContentView(view: View, params: ViewGroup.LayoutParams?) {
        with(binding.contentViewContainer) {
            removeAllViews()
            addView(view, params)
        }
    }

    override fun setContentView(view: View) {
        with(binding.contentViewContainer) {
            removeAllViews()
            addView(view)
        }
    }
}