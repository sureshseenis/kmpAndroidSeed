/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.LayoutRes
import androidx.annotation.StringRes
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.RecyclerView
import com.live.clientme.android.core.R
import com.live.clientme.android.core.databinding.DialogBaseBinding
import com.live.clientme.android.core.domain.BaseResult
import com.live.clientme.android.core.ui.event.EventInfo
import com.live.clientme.android.core.ui.event.LiveEvent
import com.live.clientme.android.core.ui.models.ToolBarModel
import com.live.clientme.android.core.ui.utils.KeyboardUtility
import com.live.clientme.android.core.ui.utils.ToastUtility
import javax.inject.Inject


abstract class BaseDialogFragment : DialogFragment() {

    @Inject
    lateinit var mViewModelFactory: ViewModelProvider.Factory

    private lateinit var binding: DialogBaseBinding
    private val toolbarModel = ToolBarModel()

    //Make floating windows full screen
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setStyle(STYLE_NO_TITLE, R.style.FullScreenDialog)
    }

    abstract fun onCreateDialogView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View?

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = getBinding(inflater, R.layout.dialog_base, container)
        val view = onCreateDialogView(inflater, container, savedInstanceState)
        binding.dialogContent.addView(view)
        binding.model = toolbarModel
        return binding.root
    }

    protected inline fun <reified T : BaseViewModel> getActivityScopedViewModel(): T {
        return ViewModelProvider(requireActivity(), mViewModelFactory).get(T::class.java)
    }

    protected inline fun <reified T : BaseViewModel> getViewModel(): T {
        return ViewModelProvider(this, mViewModelFactory).get(T::class.java)
    }

    protected fun <T : ViewDataBinding> getBinding(
        inflater: LayoutInflater, @LayoutRes layoutRes: Int, container: ViewGroup?,
        attachToParent: Boolean = false
    ): T {
        return DataBindingUtil.inflate(inflater, layoutRes, container, attachToParent)
    }

    protected fun shortToast(content: String?) {
        ToastUtility.shortToast(this.requireContext(), content)
    }

    protected fun longToast(content: String?) {
        ToastUtility.longToast(this.requireContext(), content)
    }

    protected fun shortToast(@StringRes resource: Int) {
        shortToast(getString(resource))
    }

    protected fun longToast(@StringRes resource: Int) {
        longToast(getString(resource))
    }

    protected fun setTitle(@StringRes textRes: Int) {
        setTitle(resources.getString(textRes))
    }

    protected fun setTitle(text: String?) {
        toolbarModel.title.set(text)
        binding.executePendingBindings()
    }

    protected fun setNavigationIcon(drawableId: Int, navAction: (() -> Unit)? = null) {
        val toolbar = binding.includeToolbar.toolbar
        toolbar.setNavigationIcon(drawableId)
        toolbar.setNavigationOnClickListener {
            navAction?.invoke()
            dismiss()
        }
    }

    protected fun dismissKeyboardOnScroll(recyclerView: RecyclerView?) {
        recyclerView?.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                if (dy != 0) dismissKeyboard()
                super.onScrolled(recyclerView, dx, dy)
            }
        })
    }

    protected fun dismissKeyboardOnTouch(containerView: View) {
        containerView.setOnClickListener {
            dismissKeyboard()
        }
    }

    protected fun dismissKeyboard() {
        KeyboardUtility.dismissKeyboard(activity)
    }

    protected fun observe(liveEvent: LiveEvent, onEvent: (EventInfo<String?>) -> Unit) {
        liveEvent.observe(this) {
            onEvent(it)
            onBaseEvents(it)
        }
    }

    open fun onBaseEvents(event: EventInfo<String?>) {
        (requireActivity() as BaseActivity).onBaseEvents(event.key)
    }

    protected fun <T : BaseResult> observe(
        liveData: LiveData<T>,
        onData: (T) -> Unit,
    ) {
        observe(liveData = liveData, onData = onData, handleBaseError = true)
    }

    protected fun <T : BaseResult> observe(
        liveData: LiveData<T>,
        onData: (T) -> Unit,
        handleBaseError: Boolean = true
    ) {
        observeInternal(liveData = liveData, onData = onData, { code, msg ->
            onBaseEvents(code, msg)
        }, handleBaseError = handleBaseError)
    }

    open fun onBaseEvents(
        errorCode: String?,
        message: String = getString(R.string.generic_error)
    ) {
        (requireActivity() as BaseActivity).onBaseEvents(errorCode)
    }
}