/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.ui.event

/**
 *
 * Used as a wrapper for data (usually exposed via a LiveData) that represents an event.
 * Reference: https://medium.com/androiddevelopers/livedata-with-snackbar-navigation-and-other-events-the-singleliveevent-case-ac2622673150
 */
class Event<Data>(private val content: EventInfo<Data?>) {

    var hasBeenHandled = false
        private set // Allow external read but not write

    /**
     * Returns the content and prevents its use again.
     */
    fun getUnhandledContent(): EventInfo<Data?>? {
        return if (hasBeenHandled) null else {
            hasBeenHandled = true
            content
        }
    }

    /**
     * Returns the content, even if it's already been handled.
     */
    fun peekContent(): EventInfo<Data?> = content

    companion object {
        fun <Data> create(key: String, data: Data? = null): Event<Data> {
            val content: EventInfo<Data?> =
                EventInfo(key, data)
            return Event(content)
        }
    }
}

/**
 * Data class holding navigation event info
 *
 * @param key tells the destination information
 * @param data holds the data for the destination
 */
data class EventInfo<T>(val key: String, val data: T? = null)