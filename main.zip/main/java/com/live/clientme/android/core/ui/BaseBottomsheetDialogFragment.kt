/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program ("Live Enterprise Employee Experience Interaction Suite"),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.ui

import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.PorterDuff
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.LayoutRes
import androidx.annotation.StringRes
import androidx.coordinatorlayout.widget.CoordinatorLayout
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.lifecycle.LiveData
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.live.clientme.android.core.R
import com.live.clientme.android.core.databinding.FragmentBaseBottomsheetDialogBinding
import com.live.clientme.android.core.domain.BaseResult
import com.live.clientme.android.core.ui.event.LiveEvent
import com.live.clientme.android.core.ui.utils.KeyboardUtility
import com.live.clientme.android.core.ui.utils.ToastUtility

/**
 * Parent class for BottomSheetDialog
 */

open class BaseBottomsheetDialogFragment : BottomSheetDialogFragment() {

    private lateinit var binding: FragmentBaseBottomsheetDialogBinding

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = getBinding(inflater, R.layout.fragment_base_bottomsheet_dialog, container)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setBackgroundColor()
        setMargin()
        setBottomSheetBehaviour()
    }

    private fun setBackgroundColor() {
        val bottomSheet = (requireView().parent as View)
        bottomSheet.backgroundTintMode = PorterDuff.Mode.CLEAR
        bottomSheet.backgroundTintList = ColorStateList.valueOf(Color.TRANSPARENT)
        bottomSheet.setBackgroundColor(Color.TRANSPARENT)
    }

    private fun setMargin() {
        val parent = requireView().parent as View
        val layoutParams = parent.layoutParams as CoordinatorLayout.LayoutParams
        layoutParams.setMargins(ZERO, ZERO, ZERO, ZERO)
        parent.layoutParams = layoutParams
    }

    private fun setBottomSheetBehaviour() {
        val bottomSheetBehavior = BottomSheetBehavior.from(requireView().parent as View)
        bottomSheetBehavior.isDraggable = false
        bottomSheetBehavior.state = BottomSheetBehavior.STATE_EXPANDED
    }

    protected fun <T : ViewDataBinding> getBinding(
        inflater: LayoutInflater, @LayoutRes layoutRes: Int, container: ViewGroup?,
        attachToParent: Boolean = false
    ): T {
        return DataBindingUtil.inflate(inflater, layoutRes, container, attachToParent)
    }

    protected inline fun <reified T : BaseViewModel> getActivityScopedViewModel(): T {
        val model: T by activityViewModels()
        return model
    }

    protected inline fun <reified T : BaseViewModel> getViewModel(): T {
        val model: T by viewModels()
        return model
    }

    protected fun shortToast(content: String?) {
        ToastUtility.shortToast(this.requireContext(), content)
    }

    protected fun longToast(content: String?) {
        ToastUtility.longToast(this.requireContext(), content)
    }

    protected fun shortToast(@StringRes resource: Int) {
        shortToast(getString(resource))
    }

    protected fun longToast(@StringRes resource: Int) {
        longToast(getString(resource))
    }

    protected fun dismissKeyboard() {
        KeyboardUtility.dismissKeyboard(activity)
    }

    protected fun observe(
        liveEvent: LiveEvent,
        onSuccess: () -> Unit,
        handleBaseError: Boolean = true,
        onFailure: ((errorCode: String) -> Unit)? = null
    ) {
        observeInternal(
            liveEvent = liveEvent,
            onSuccess = onSuccess,
            handleBaseError = handleBaseError,
            onFailure = onFailure,
            onBaseEvents = { onBaseEvents(it) }
        )
    }

    protected fun <T : BaseResult> observe(
        liveData: LiveData<T>,
        onData: (T) -> Unit,
    ) {
        observe(liveData = liveData, onData = onData, handleBaseError = true)
    }

    protected fun <T : BaseResult> observe(
        liveData: LiveData<T>,
        onData: (T) -> Unit,
        handleBaseError: Boolean = true
    ) {
        observeInternal(liveData = liveData, onData = onData, { code, msg ->
            onBaseEvents(code, msg)
        }, handleBaseError = handleBaseError)
    }

    open fun onBaseEvents(
        errorCode: String?,
        message: String = getString(R.string.generic_error)
    ) {
        (requireActivity() as BaseActivity).onBaseEvents(errorCode)
    }

    companion object {
        const val ZERO = 0
    }
}