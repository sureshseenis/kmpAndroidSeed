/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program ("Live Enterprise Employee Experience Interaction Suite"),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.ui

import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LiveData
import com.live.clientme.android.core.domain.BaseResult
import com.live.clientme.android.core.ui.event.LiveEvent


/**
 * Much simpler way of observing a LiveEvent.
 *
 * @param liveEvent The liveEvent that is being observed
 * @param onSuccess The success callback
 * @param onFailure The failure callback. This is optional.
 * Supply this parameter, If the observer wants to handle custom error scenarios.
 * Return true if the base errors should be handled.
 * If this is not provided only base errors will be handled.
 *
 * Example:
 *
 * observe(viewModel.login(), onSuccess = {
 *      //Handle success scenarios
 * }, onFailure = {
 *      // Handle error scenarios
 *      // return true if errors are already handled completely,
 *      // otherwise return false to handle base errors automatically.
 *      // If this is not supplied base errors will be handled automatically
 *      true
 * })
 *
 */
fun LifecycleOwner.observeInternal(
    liveEvent: LiveEvent,
    onSuccess: () -> Unit,
    handleBaseError: Boolean = true,
    onFailure: ((errorCode: String) -> Unit)? = null,
    onBaseEvents: (key: String) -> Unit
) {
    liveEvent.observe(this) {
        when (it.key) {
            CoreEvents.SUCCESS -> onSuccess()
            else -> {
                onFailure?.invoke(it.key)
                if (handleBaseError) onBaseEvents(it.key)
            }
        }
    }
}

fun <T : BaseResult> LifecycleOwner.observeInternal(
    liveData: LiveData<T>,
    onData: (T) -> Unit,
    onBaseEvents: (errorCode: String?, errorMsg: String) -> Unit,
    handleBaseError: Boolean = true
) {
    liveData.observe(this) {
        onData(it)
        if (handleBaseError) {
            onBaseEvents(it.errorResult?.errorCode, it.errorResult?.errorMsg ?: "")
        }
    }
}