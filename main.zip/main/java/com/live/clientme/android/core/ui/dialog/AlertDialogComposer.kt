/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.ui.dialog

import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.view.View
import androidx.annotation.IntegerRes
import androidx.appcompat.app.AlertDialog

object AlertDialogComposer {

    fun createDialog(
        context: Context,
        title: String,
        message: String,
        pText: String,
        pListener: DialogInterface.OnClickListener? = null,
        nText: String? = null,
        nListener: DialogInterface.OnClickListener? = null
    ): AlertDialog {
        val dialog = AlertDialog.Builder(context)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton(pText, pListener)
            .setNegativeButton(nText, nListener)
            .setCancelable(false)
            .create()

        dialog.setCanceledOnTouchOutside(false)
        return dialog
    }

    fun createMaterialDialog(
        context: Context,
        title: String,
        message: String,
        pText: String,
        pListener: DialogInterface.OnClickListener? = null,
        nText: String? = null,
        nListener: DialogInterface.OnClickListener? = null
    ): Dialog {
        return MaterialDialog(context).also {
            if (title != "") {
                it.setTitle(title)
            }
            it.setMessage(message)
            it.setPositiveButton(pText, pListener)
            it.setNegativeButton(nText, nListener)
            it.setCancelable(false)
        }
    }

    fun createMaterialDialog(
        context: Context,
        title: String,
        @IntegerRes layout: Int,
        pText: String,
        pListener: DialogInterface.OnClickListener? = null,
        nText: String? = null,
        nListener: DialogInterface.OnClickListener? = null
    ): Dialog {
        return MaterialDialog(context).also {
            it.setTitle(title)
            it.setContentView(layout)
            it.setPositiveButton(pText, pListener)
            it.setNegativeButton(nText, nListener)
            it.setCancelable(false)
        }
    }

    fun createMaterialDialog(
        context: Context,
        title: String,
        view: View,
        pText: String,
        pListener: DialogInterface.OnClickListener? = null,
        nText: String? = null,
        nListener: DialogInterface.OnClickListener? = null
    ): Dialog {
        return MaterialDialog(context).also {
            it.setTitle(title)
            it.setContentView(view)
            it.setPositiveButton(pText, pListener)
            it.setNegativeButton(nText, nListener)
            it.setCancelable(false)
        }
    }

    fun createMaterialDialog(
        context: Context,
        message: String,
        pText: String,
        pListener: DialogInterface.OnClickListener? = null,
    ): Dialog {
        return MaterialDialog(context).also {
            it.setMessage(message)
            it.setPositiveButton(pText, pListener)
            it.setCancelable(false)
        }
    }
}