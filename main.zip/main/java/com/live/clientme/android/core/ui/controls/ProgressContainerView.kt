/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.ui.controls

import android.content.Context
import android.util.AttributeSet
import android.util.Log
import android.view.LayoutInflater
import android.widget.RelativeLayout
import androidx.databinding.ObservableBoolean
import androidx.databinding.ObservableField
import com.live.clientme.android.core.databinding.ProgressViewBinding

class ProgressContainerView : RelativeLayout {

    private val progressView =
        ProgressViewBinding.inflate(LayoutInflater.from(context), this, true)

    constructor(context: Context?) : super(context)
    constructor(context: Context?, attrs: AttributeSet?) : super(context, attrs)
    constructor(context: Context?, attrs: AttributeSet?, defStyleAttr: Int) : super(
        context,
        attrs,
        defStyleAttr
    )

    fun setProgressModel(model: ProgressModel) {
        progressView.model = model
        progressView.executePendingBindings()
    }
}

class ProgressModel {
    val errorText = ObservableField("Oh! Snap.. Something went wrong. :(")
    val retryText = ObservableField("Retry")
    val emptyText = ObservableField("Nothing to see here!")
    val taskProgressing = ObservableBoolean(false)
    val taskFailed = ObservableBoolean(false)
    val taskBlank = ObservableBoolean(false)
    val taskSuccess = ObservableBoolean(false)
    var retryListener: (() -> Unit)? = null

    private var taskCount = 1

    fun startTaskProgress(taskCount: Int = 1) {
        this.taskCount = taskCount
        taskProgressing.set(true)
        taskFailed.set(false)
        taskBlank.set(false)
    }

    fun stopTaskProgress() {
        taskCount -= 1
        if (taskCount <= 0) {
            stopProgress()
        }
    }

    fun stopProgress() {
        taskBlank.set(false)
        taskProgressing.set(false)
        taskFailed.set(false)
        taskSuccess.set(true)
    }

    fun showRetryView(retryListener: () -> Unit) {
        this.retryListener = retryListener
        if (taskCount <= 1) {
            taskBlank.set(false)
            taskProgressing.set(false)
            taskFailed.set(true)
        } else {
            Log.e(
                ProgressModel::class.java.simpleName,
                "cannot show retry view with more than one task is in progress"
            )
        }
    }

    fun showEmptyView() {
        taskBlank.set(true)
        taskBlank.notifyChange()
        taskProgressing.set(false)
        taskFailed.set(false)
    }

    fun hideEmptyView() {
        taskBlank.set(false)
        taskProgressing.set(false)
        taskFailed.set(false)
    }

    fun setEmptyText(text: String) {
        emptyText.set(text)
    }

    fun setRetryButton(text: String) {
        retryText.set(text)
    }

    fun setErrorText(text: String) {
        errorText.set(text)
    }
}