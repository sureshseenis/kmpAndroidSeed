/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.ui.event

import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Observer

/**
 *
 * LiveData in which events are propagated.
 *
 * Simultaneous emitting of data not supported. If done so,
 * then only the latest data is delivered.
 *
 * Only one observer is supported at a time. Also note that events are propagated only once.
 * Once an event is emitted, it can be observed only once.
 *
 * Any data content propagated with the event should be in a bundle.
 *
 */

class LiveEvent : BaseLiveEvent<String?>() {

    fun postEvent(key: String, value: String) {
        super.postValue(Event.create(key, value))
    }
}

open class BaseLiveEvent<Data> : MutableLiveData<Event<Data?>>() {

    fun postEvent(key: String) {
        super.postValue(Event.create(key))
    }

    fun observe(owner: LifecycleOwner, onEvent: (EventInfo<Data?>) -> Unit) {
        if (hasObservers()) {
            println("This LiveEvent already have an observer. Removing previous observer")
            removeObservers(owner)
        }
        super.observe(owner, {
            val content = it?.getUnhandledContent()
            if (content != null) {
                onEvent(content)
            }
        })
    }

    override fun observe(owner: LifecycleOwner, observer: Observer<in Event<Data?>>) {
        println("This method is not supported. Call observe(owner: LifecycleOwner, onEvent: (EventInfo<Bundle?>) -> Unit) instead")
        super.observe(owner, observer)
    }
}