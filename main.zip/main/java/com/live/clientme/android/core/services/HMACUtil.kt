/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */
package com.live.clientme.android.core.services

import android.os.Build
import android.util.Base64.encodeToString
import android.util.Log
import java.math.BigInteger
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException
import java.security.SecureRandom
import java.sql.Timestamp
import java.time.Instant
import java.util.*
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

object HMACUtil {

    private const val APP_ID = ""
    private const val HMAC_ALGORITHM = "HmacSHA256"
    private const val HASHING_ALGORITHM = "MD5"
    private const val AUTH_TYPE = "HMAC"
    private const val MD5_RADIX = 16
    private const val MD5_LENGTH = 32
    private const val SIGNUM = 1
    private const val NONCE_FORMAT = "%02x"
    private const val NONCE_BYTE_SIZE = 16
    private const val TIME_CONVERSION = 1000L
    private val TAG = HMACUtil::class.qualifiedName

    fun getHMACKey(
        apiKey: String,
        requestURI: String,
        requestBody: String,
        requestMethod: String,
        requestNonce: String,
        requestTimeStamp: String
    ): String {

        val hMacRequestContentMd5 = getMd5(requestBody)

        val hMacDataToSign =
            "$APP_ID$requestMethod$requestURI$requestTimeStamp$requestNonce$hMacRequestContentMd5"

        val sha = Mac.getInstance(HMAC_ALGORITHM)
        val secretKey = SecretKeySpec(apiKey.toByteArray(), HMAC_ALGORITHM)
        sha.init(secretKey)

        val shaBytes = sha.doFinal(hMacDataToSign.toByteArray())

        val hMacSignedKey = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Base64.getEncoder().encodeToString(shaBytes)
        } else {
            encodeToString(shaBytes, android.util.Base64.DEFAULT)
        }

        return "$AUTH_TYPE ${APP_ID}:$hMacSignedKey:$requestNonce:$requestTimeStamp"
    }

    fun getCurrentTimeStamp() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        val instant = Instant.now()
        instant.epochSecond.toString()
    } else {
        val timestamp =
            Timestamp(System.currentTimeMillis() / TIME_CONVERSION)
        timestamp.time.toString()
    }

    fun generateNonce(): ByteArray {
        val nonceBytes = ByteArray(NONCE_BYTE_SIZE)
        SecureRandom().nextBytes(nonceBytes)
        return nonceBytes
    }

    fun convertBytesToHex(nonceBytes: ByteArray): String {
        val nonce = StringBuilder()
        for (byte in nonceBytes) {
            nonce.append(String.format(NONCE_FORMAT, byte))
        }
        return nonce.toString()
    }

    fun getMd5(requestBody: String): String {
        return try {

            //Static getInstance method is called with hashing MD5
            val md: MessageDigest = MessageDigest.getInstance(HASHING_ALGORITHM)

            /*digest() method is called to calculate message digest of an input digest() return array of byte*/
            val messageDigest: ByteArray = md.digest(requestBody.toByteArray())

            // Convert byte array into signum representation
            val signum = BigInteger(SIGNUM, messageDigest)

            // Convert message digest into hex value
            var contentmd5: String = signum.toString(MD5_RADIX)
            while (contentmd5.length < MD5_LENGTH) {
                contentmd5 = "0$contentmd5"
            }
            contentmd5
        } catch (e: NoSuchAlgorithmException) {
            Log.e(TAG, e.toString())
            ""
        }
    }

}
