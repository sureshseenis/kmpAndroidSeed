/*
 * © 2023 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program ("Live Enterprise Employee Experience Interaction Suite"),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.view.View
import androidx.activity.viewModels
import androidx.annotation.LayoutRes
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.databinding.ViewDataBinding
import androidx.lifecycle.LiveData
import com.google.android.material.snackbar.Snackbar
import com.infosys.telemetry.event.Event
import com.live.clientme.android.core.R
import com.live.clientme.android.core.domain.BaseResult
import com.live.clientme.android.core.domain.ErrorCodes
import com.live.clientme.android.core.ui.dialog.AlertDialogUtility
import com.live.clientme.android.core.ui.event.LiveEvent
import com.live.clientme.android.core.ui.event.TelemetryEventProvider
import com.live.clientme.android.core.ui.utils.KeyboardUtility
import com.live.clientme.android.core.ui.utils.ToastUtility
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject


/**
 * Parent class for Activities.
 */
@SuppressLint("Registered")
@AndroidEntryPoint
abstract class BaseActivity : AppCompatActivity() {

    @Inject
    lateinit var telemetryEventProvider: TelemetryEventProvider

    /**
     * Method to create and retrieve the appropriate ViewModel class
     *
     * @param <T>   Type of the ViewModel
     * @return Created ViewModel
     */

    @Deprecated(
        message = "use viewModels() directly in the activity",
        ReplaceWith("by viewModels()")
    )
    protected inline fun <reified T : BaseViewModel> getViewModel(): T {
        val model: T by viewModels()
        return model
    }

    /**
     * Set the Activity's content view to the given layout and return the associated binding.
     *
     * @param layoutRes The resource ID of the layout to be inflated, bound, and set as the
     *                  Activity's content.
     * @param <T>       Type of the generated binding class.
     * @return The binding associated with the inflated content view or null if the layoutId is not
     * a data binding layout.
     */
    protected fun <T : ViewDataBinding> getBinding(@LayoutRes layoutRes: Int): T {
        return DataBindingUtil.setContentView(this, layoutRes)
    }

    /**
     * Shows a short toast
     */
    protected fun shortToast(content: String?) {
        ToastUtility.shortToast(this, content)
    }

    /**
     * Shows a long toast
     */
    protected fun longToast(content: String?) {
        ToastUtility.longToast(this, content)
    }

    /**
     * show a dismissible SnackBar
     */
    private fun showSnackBar(content: Int) {
        val snack: Snackbar = Snackbar.make(
            findViewById(android.R.id.content),
            content,
            Snackbar.LENGTH_INDEFINITE
        )
        snack.setAction(
            R.string.label_dismiss
        ) {
            snack.dismiss()
        }
        snack.show()
    }

    protected fun observe(
        liveEvent: LiveEvent,
        onSuccess: () -> Unit,
        handleBaseError: Boolean = true,
        onFailure: ((errorCode: String) -> Unit)? = null
    ) {
        observeInternal(
            liveEvent = liveEvent,
            onSuccess = onSuccess,
            onFailure = onFailure,
            handleBaseError = handleBaseError,
            onBaseEvents = { onBaseEvents(it) }
        )
    }

    protected fun <T : BaseResult> observe(
        liveData: LiveData<T>,
        onData: (T) -> Unit,
    ) {
        observe(liveData = liveData, onData = onData, handleBaseError = true)
    }

    protected fun <T : BaseResult> observe(
        liveData: LiveData<T>,
        onData: (T) -> Unit,
        handleBaseError: Boolean = true
    ) {
        observeInternal(liveData = liveData, onData = onData, { code, msg ->
            onBaseEvents(code, msg)
        }, handleBaseError = handleBaseError)
    }

    open fun onBaseEvents(
        errorResult: String?,
        message: String = getString(R.string.generic_error)
    ) {
        when (errorResult) {
            ErrorCodes.Base.UNAUTHORIZED_ERROR -> {
                shortToast(getString(R.string.auth_error))
                logOut()
            }
            ErrorCodes.Base.FORCE_UPDATE_ERROR -> {
                showAppUpdateDialog()
            }
            ErrorCodes.Base.SOFT_UPDATE_ERROR -> {
                showAppUpdateDialog()
            }
            ErrorCodes.Base.UNSUPPORTED_MEDIA_TYPE -> shortToast(message)
            ErrorCodes.Base.NETWORK_ERROR,
            ErrorCodes.Base.IO_ERROR -> showSnackBar(R.string.no_internet)
            ErrorCodes.Base.GENERIC_ERROR,
            ErrorCodes.Base.INTERNAL_SERVER_ERROR -> AlertDialogUtility.showGenericErrorDialog(this)
            ErrorCodes.Base.BAD_REQUEST -> shortToast(message)

        }
    }

    /**
     * Override fun to manage user logout flow
     */
    open fun logOut() {
        //Optional implementation will be done in subclass
    }

    private fun showAppUpdateDialog() {
        AlertDialogUtility.showAppUpdateDialog(this, pListener = { _, _ ->
            updateApplication()
        }, nListener = { _, _ ->
            finish()
        })
    }

    /**
     * Update application from Play store
     */
    private fun updateApplication() {
        val intent = Intent(Intent.ACTION_VIEW)
        intent.data = Uri.parse(getString(R.string.store_url) + applicationContext.packageName)
        startActivity(intent)
    }

    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }

    protected fun dismissKeyboard() {
        KeyboardUtility.dismissKeyboard(this)
    }

    protected fun dismissKeyboardOnTouch(containerView: View) {
        containerView.setOnClickListener {
            dismissKeyboard()
        }
    }

    fun configureTelemetry(email: String, token: String) {
        telemetryEventProvider.init(this, email, token)
    }

    fun logStartEvent(eventKey: String, eventValue: String) {
        logEvent(Event.START, eventKey, eventValue)
    }

    fun logImpressionEvent(eventKey: String, eventValue: String) {
        logEvent(Event.IMPRESSION, eventKey, eventValue)
    }

    fun logEvent(
        eventType: String,
        eventKey: String,
        eventValue: String,
        realTime: Boolean = true
    ) {
        telemetryEventProvider.logEvent(this, eventType, eventKey, eventValue, realTime)
    }
}