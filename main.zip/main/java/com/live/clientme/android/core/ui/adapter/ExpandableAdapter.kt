/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.live.clientme.android.core.R
import com.live.clientme.android.core.databinding.BaseExpandableGroupViewBinding

abstract class ExpandableAdapter<T : ExpandableGroupItemModel>(
    private val dataList: ArrayList<T>
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private lateinit var parentRecyclerView: RecyclerView
    private var expandedIndex = -1
    var parentClickListener: ((Int) -> Unit)? = null

    /**
     * set this as true, if multiple item should be expanded at a time
     * set this as false, if only one item should be expanded at a time
     */
    var enableMultiExpand = false

    abstract fun onCreateGroupViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder

    abstract fun onCreateChildViewHolder(
        parent: ViewGroup,
        viewType: Int,
        groupPosition: Int
    ): RecyclerView.ViewHolder

    abstract fun getChildItemCount(groupPosition: Int): Int

    abstract fun getGroupItemCount(): Int

    abstract fun onBindGroupViewHolder(
        holder: RecyclerView.ViewHolder,
        position: Int,
        expanded: Boolean
    )

    abstract fun onBindChildViewHolder(
        holder: RecyclerView.ViewHolder,
        groupPosition: Int,
        childPosition: Int
    )

    open fun getChildItemViewType(groupPosition: Int, childPosition: Int) = 1

    open fun getGroupItemViewType(position: Int) = 1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = BaseExpandableGroupViewBinding.inflate(inflater, parent, false)
        val vh = onCreateGroupViewHolder(parent, viewType)
        return GroupViewHolder(binding, vh)
    }

    override fun getItemCount(): Int {
        return getGroupItemCount()
    }

    fun notifyChildItemRemoved(groupPosition: Int, position: Int) {
        val view = parentRecyclerView.layoutManager?.findViewByPosition(groupPosition)
        (view?.findViewById(R.id.childContainer) as RecyclerView).adapter?.notifyItemRemoved(
            position
        )
    }

    fun notifyChildItemInserted(groupPosition: Int, position: Int) {
        val view = parentRecyclerView.layoutManager?.findViewByPosition(groupPosition)
        (view?.findViewById(R.id.childContainer) as RecyclerView).adapter?.notifyItemInserted(
            position
        )
    }

    fun notifyChildItemChanged(groupPosition: Int, position: Int) {
        val view = parentRecyclerView.layoutManager?.findViewByPosition(groupPosition)
        (view?.findViewById(R.id.childContainer) as RecyclerView).adapter?.notifyItemChanged(
            position
        )
    }

    fun notifyChildItemRangeChanged(groupPosition: Int, positionStart: Int, itemCount: Int) {
        val view = parentRecyclerView.layoutManager?.findViewByPosition(groupPosition)
        (view?.findViewById(R.id.childContainer) as RecyclerView).adapter?.notifyItemRangeChanged(
            positionStart,
            itemCount
        )
    }

    fun scrollToChildPosition(itemPosition: Int, categoryPosition: Int) {
        val view = parentRecyclerView.layoutManager?.findViewByPosition(categoryPosition)
        (view?.findViewById(R.id.childContainer) as RecyclerView).smoothScrollToPosition(
            itemPosition
        )
    }

    fun setExpandedIndex(adapterPosition: Int) {
        expandedIndex = dataList.indexOfFirst { it.isExpanded }
        if (expandedIndex >= 0 && expandedIndex != adapterPosition && expandedIndex < dataList.size) {
            dataList[expandedIndex].isExpanded = false
            notifyItemChanged(expandedIndex)
        }
        dataList[adapterPosition].isExpanded = true
        expandedIndex = adapterPosition
    }

    fun getExpandStatusOfParent(position: Int): Boolean {
        return dataList[position].isExpanded
    }

    override fun getItemViewType(position: Int): Int {
        return getGroupItemViewType(position)
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val groupViewHolder = holder as GroupViewHolder

        setUpChildRecyclerView(groupViewHolder.childContainer, position)
        val item = dataList[position]
        val linearLayout = holder.itemView.findViewById(R.id.parentContainer) as LinearLayout
        linearLayout.setOnClickListener {
            val adapterPosition = holder.adapterPosition
            if (!enableMultiExpand) {
                if (expandedIndex >= 0 && expandedIndex != adapterPosition && expandedIndex < dataList.size) {
                    dataList[expandedIndex].isExpanded = false
                    notifyItemChanged(expandedIndex)
                }
                toggle(item, adapterPosition)
                expandedIndex = when {
                    item.isExpanded -> adapterPosition
                    else -> -1
                }
            } else {
                toggle(item, adapterPosition)
            }
            parentClickListener?.invoke(adapterPosition)
            notifyItemChanged(adapterPosition)
        }
        var visibility = View.GONE
        if (item.isExpanded) {
            visibility = View.VISIBLE
            expandedIndex = position
        }
        groupViewHolder.childContainer.visibility = visibility
        onBindGroupViewHolder(groupViewHolder.vh, position, item.isExpanded)
    }

    private fun toggle(item: T, adapterPosition: Int) {
        item.isExpanded = item.isExpanded.not()
        parentRecyclerView.smoothScrollToPosition(adapterPosition)
    }

    private fun setUpChildRecyclerView(
        childContainer: RecyclerView,
        groupPosition: Int
    ) {
        childContainer.adapter = ChildAdapter(groupPosition)
        childContainer.layoutManager = LinearLayoutManager(childContainer.context)
    }

    inner class ChildAdapter(private val groupPosition: Int) :
        RecyclerView.Adapter<RecyclerView.ViewHolder>() {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
            return onCreateChildViewHolder(parent, viewType, groupPosition)
        }

        override fun getItemCount(): Int {
            return getChildItemCount(groupPosition)
        }

        override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
            onBindChildViewHolder(holder, groupPosition, position)
        }

        override fun getItemViewType(position: Int): Int {
            return getChildItemViewType(groupPosition, position)
        }
    }

    override fun onAttachedToRecyclerView(recyclerView: RecyclerView) {
        this.parentRecyclerView = recyclerView
        super.onAttachedToRecyclerView(recyclerView)
    }
}

open class ExpandableGroupItemModel {
    internal var isExpanded: Boolean = false
}

open class GroupViewHolder(
    binding: BaseExpandableGroupViewBinding,
    internal val vh: RecyclerView.ViewHolder
) :
    RecyclerView.ViewHolder(binding.root) {

    internal val childContainer: RecyclerView

    init {
        binding.parentContainer.addView(vh.itemView)
        this.childContainer = binding.childContainer
    }
}