/*
 * © 2023 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.ui.utils

import android.content.Context
import android.text.format.DateUtils
import com.live.clientme.android.core.R
import java.text.ParseException
import java.text.SimpleDateFormat
import java.time.LocalDateTime
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs

object DateTimeFormatterUtility {
    const val TIME_FORMAT = "hh:mm"
    const val DAY_TIME_FORMAT = "EEE, HH:mm"
    const val DEFAULT_TIME_FORMAT = "HH:mm"
    const val DAY_FULL_NAME = "EEEE"
    const val MONTH_NAME_SHORT = "MMM"
    const val MONTH_NAME_FULL = "MMMM"
    const val DATE_YYYY_MM_DD = "yyyy-MM-dd"
    const val DATE_TIME_FORMAT = "yyyy-MM-dd'T'HH:mm:ss"
    const val DATE_DD_MMM_YYYY = "dd MMM yyyy"
    const val DATE_DD_MMM_YYYY_TIME = "E, dd MMM yyyy hh:mm aaa"
    const val TODO_DD_MMM_YYYY_TIME = "dd-mm-yyyy HH:MM"
    const val TODO_YYYY_MM_DD_TIME = "yyyy-MM-dd'T'HH:mm:ss'Z'"
    const val DATE_TIME_SEC_FORMAT = "yyyy-MM-dd'T'HH:mm:ss"
    const val SHOW_DATE_FORMAT = "dd MMM yyyy"
    const val TIME_FORMAT_AM_PM = "hh:mm a"
    const val DATE_TIME_SEC_FORMAT_WITHOUT_T = "yyyy-MM-dd HH:mm:ss"
    const val DATE_FORMAT_SEC_SSS_Z = "yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"
    private const val SHOW_DATE_TIME_FORMAT = "HH:mm aaa, dd MMM yyyy"
    const val TIME_ZONE_GMT = "GMT"
    const val TIME_ZONE_UTC = "UTC"
    const val ZERO = 0L
    const val DAYS_IN_YEAR = 365
    const val DAYS_IN_MONTH = 30
    const val DAYS_IN_WEEK = 7
    const val WEEK_IN_MONTH = 4
    const val HOURS_IN_DAY = 24
    const val MINUTES_IN_HOURS = 60
    const val SECONDS_IN_MINUTES = 60

    fun millisToTime(millis: Long): String {
        val formatter =
            SimpleDateFormat(DEFAULT_TIME_FORMAT, Locale.US)
        return formatter.format(Date(millis))
    }

    fun getDayName(date: Date): String {
        val formatter =
            SimpleDateFormat(DAY_FULL_NAME, Locale.US)
        return formatter.format(date)
    }

    fun convertDateTimeToTime(dateString: String?, format: String?): String? {
        if (dateString.isNullOrEmpty())
            return null
        return try {
            val parser = SimpleDateFormat(DATE_TIME_FORMAT, Locale.getDefault()).parse(dateString)
            return SimpleDateFormat(format, Locale.getDefault()).format(parser ?: 0).uppercase()
        } catch (ex: Exception) {
            null
        }
    }

    fun convertUTCDateTimeToLocalTime(dateString: String?, format: String?): String? {
        return try {
            val utcFormat = SimpleDateFormat(DATE_TIME_SEC_FORMAT, Locale.US)
            utcFormat.timeZone = TimeZone.getTimeZone(TIME_ZONE_UTC)
            val date = dateString?.let { utcFormat.parse(it) } ?: return null
            val localFormat = SimpleDateFormat(format, Locale.getDefault())
            localFormat.timeZone = TimeZone.getDefault()
            localFormat.format(date)
        } catch (ex: Exception) {
            null
        }
    }

    fun toDoDateFomatter(dateString: SimpleDateFormat?, format: String?): String? {
        return try {
            val parser = SimpleDateFormat(format, Locale.getDefault())
            return parser.format(dateString)
        } catch (ex: Exception) {
            null
        }
    }

    fun convertTimeToLong(time: String): Long {
        val format = SimpleDateFormat(TIME_FORMAT, Locale.getDefault())
        try {
            val date = format.parse(time)
            return date?.time ?: 0
        } catch (e: ParseException) {
            e.printStackTrace()
        }
        return 0
    }

    fun getTimeZone(): String {
        return TimeZone.getDefault().displayName
    }

    fun getDefaultTimeZoneId(): String {
        return TimeZone.getDefault().id
    }

    fun getCurrentDate(format: String = DATE_YYYY_MM_DD): String {
        val dateFormatter: DateTimeFormatter = DateTimeFormatter.ofPattern(format, Locale.ENGLISH)
        return dateFormatter.format(LocalDateTime.now())
    }

    fun getCurrentLocalDate(): Date {
        return Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant())
    }

    fun getNextDate(format: String = DATE_YYYY_MM_DD): String {
        val dateFormatter: DateTimeFormatter = DateTimeFormatter.ofPattern(format, Locale.ENGLISH)
        val date = LocalDateTime.now()
        date.plusDays(1)
        return dateFormatter.format(date)
    }

    fun getPrevDate(format: String = DATE_YYYY_MM_DD): String {
        val dateFormatter: DateTimeFormatter = DateTimeFormatter.ofPattern(format, Locale.ENGLISH)
        val date = LocalDateTime.now()
        date.minusDays(1)
        return dateFormatter.format(date)
    }

    fun getDateTimeDifference(startTime: String): String {
        val format = SimpleDateFormat(DATE_TIME_FORMAT, Locale.getDefault())
        return try {
            format.timeZone = TimeZone.getTimeZone("UTC")
            val date1 = format.parse(startTime)
            DateUtils.getRelativeTimeSpanString(date1?.time ?: 0).toString()
        } catch (exception: Exception) {
            ""
        }
    }

    fun getDifferenceInDays(startTime: String, endTime: String): Long {
        val format = SimpleDateFormat(DATE_TIME_FORMAT, Locale.getDefault())
        return try {
            val date1 = format.parse(startTime)
            val date2 = format.parse(endTime)
            val difference = abs(date1?.time?.minus(date2?.time ?: 0) ?: 0)
            difference / (24 * 60 * 60 * 1000)
        } catch (e: Exception) {
            0
        }
    }

    fun getTimeInMillis(date: String): Long {
        val format = SimpleDateFormat(DATE_TIME_FORMAT, Locale.getDefault())
        return try {
            format.parse(date)?.time ?: 0
        } catch (exception: Exception) {
            0
        }
    }

    fun compareDateTime(date: String): Boolean {
        val format = SimpleDateFormat(DATE_YYYY_MM_DD, Locale.getDefault())
        return try {
            val startDate = format.parse(date)
            val currentDate = format.parse(getCurrentDate())
            startDate?.after(currentDate) ?: false
        } catch (e: Exception) {
            false
        }
    }

    fun isDateTimeEqual(date: String?): Boolean {
        val format = SimpleDateFormat(DATE_YYYY_MM_DD, Locale.getDefault())
        return try {
            if (date.isNullOrEmpty()) {
                return false
            }
            val startDate = format.parse(date)
            val currentDate = format.parse(getCurrentDate())
            startDate == currentDate
        } catch (e: Exception) {
            false
        }
    }


    fun getWeekDays(isCurrent: Boolean = false): String {
        val cal: Calendar = Calendar.getInstance()

        if (!isCurrent)
            cal.set(Calendar.WEEK_OF_MONTH, cal.get(Calendar.WEEK_OF_MONTH) + 1)
        //first day of week
        val firstDay = 2
        val lastDay = 6
        cal.set(Calendar.DAY_OF_WEEK, firstDay)

        val year: Int = cal.get(Calendar.YEAR)
        val firstDate: Int = cal.get(Calendar.DAY_OF_MONTH)

        //last day of week
        cal.set(Calendar.DAY_OF_WEEK, lastDay)
        val lastDate: Int = cal.get(Calendar.DAY_OF_MONTH)

        val monthFormatter = SimpleDateFormat(MONTH_NAME_SHORT, Locale.US)
        return "$firstDate-$lastDate ${monthFormatter.format(cal.time)} $year ${if (isCurrent) "(Current)" else ""}"
    }

    //TODO - days and suffix for the date's have to change for the german language
    fun getDayValue(isCurrent: Boolean = false, dayNumber: Int = 1, context: Context): String {
        val cal: Calendar = Calendar.getInstance()

        if (!isCurrent)
            cal.set(Calendar.WEEK_OF_MONTH, cal.get(Calendar.WEEK_OF_MONTH) + 1)
        val firstDay = 2 + dayNumber
        cal.set(Calendar.DAY_OF_WEEK, firstDay)
        val date: Int = cal.get(Calendar.DAY_OF_MONTH)
        val monthFormatter = SimpleDateFormat(MONTH_NAME_FULL, Locale.US)
        val dayFormatter = SimpleDateFormat(DAY_FULL_NAME, Locale.US)
        return "${dayFormatter.format(cal.time)} ${getSuffixWithDate(date, context)} ${
            monthFormatter.format(cal.time)
        }"
    }

    fun isCompareDate(toDoDate: String, selectedDate: String): Boolean {
        var isMonthSame = false
        val toDoDateParser =
            SimpleDateFormat(DATE_TIME_FORMAT, Locale.getDefault()).parse(toDoDate)
        val toDoDateFormater =
            SimpleDateFormat(MONTH_NAME_FULL, Locale.getDefault()).format(toDoDateParser ?: 0)
        val selectedDateParser =
            SimpleDateFormat(DATE_TIME_FORMAT, Locale.getDefault()).parse(selectedDate)
        val selectedDateDateFormater =
            SimpleDateFormat(MONTH_NAME_FULL, Locale.getDefault()).format(selectedDateParser ?: 0)
        isMonthSame = toDoDateFormater.equals(selectedDateDateFormater)
        return isMonthSame
    }

    fun compareDate(startDate: Date, endDate: Date, type: Int): Boolean {
        return try {
            if (type == 1)
                startDate.before(endDate)
            else
                endDate.after(startDate)
        } catch (e: Exception) {
            false
        }
    }

    fun getMonth(toDoDate: String): String {
        val toDoDateParser =
            SimpleDateFormat(DATE_TIME_FORMAT, Locale.getDefault()).parse(toDoDate)
        return SimpleDateFormat(MONTH_NAME_FULL, Locale.getDefault()).format(toDoDateParser ?: 0)
    }

    private fun getSuffixWithDate(date: Int, context: Context): String {
        return when (date) {
            1, 21, 31 -> {
                StringBuilder(date).append(context.getString(R.string.label_date_append_st))
                    .toString()
            }

            2, 22 -> {
                StringBuilder(date).append(context.getString(R.string.label_date_append_nd))
                    .toString()
            }

            3, 23 -> {
                StringBuilder(date).append(context.getString(R.string.label_date_append_rd))
                    .toString()
            }

            else -> {
                StringBuilder(date).append(context.getString(R.string.label_date_append_th))
                    .toString()
            }
        }
    }

    fun convertDateToDateTime(dateString: String?): String? {
        if (dateString.isNullOrEmpty())
            return null
        return try {
            val parser =
                SimpleDateFormat(DATE_TIME_SEC_FORMAT, Locale.getDefault()).parse(dateString)
            return SimpleDateFormat(SHOW_DATE_FORMAT, Locale.getDefault()).format(parser ?: "")
        } catch (ex: Exception) {
            null
        }
    }

    fun returnTimeDateFormat(dateString: String?): String? {
        if (dateString.isNullOrEmpty())
            return null
        return try {
            val parser =
                SimpleDateFormat(DATE_TIME_SEC_FORMAT_WITHOUT_T, Locale.getDefault()).parse(
                    dateString
                )
            return SimpleDateFormat(SHOW_DATE_TIME_FORMAT, Locale.getDefault()).format(parser ?: "")
        } catch (ex: Exception) {
            null
        }
    }

    @Throws(ParseException::class)
    fun convertDateTimeToDate(
        dateString: String?, format: String? = DATE_TIME_FORMAT, timeZoneId: String? = null
    ): Date? {
        if (dateString.isNullOrEmpty()) return null
        return SimpleDateFormat(format, Locale.getDefault()).apply {
            timeZone = if (timeZoneId.isNullOrEmpty()) TimeZone.getDefault() else
                TimeZone.getTimeZone(timeZoneId)
        }.parse(dateString)
    }

    fun timeDifferenceInMilliSeconds(
        startTime: Date?, endTime: Date?, isNegative: Boolean = false
    ): Long {
        return if (isNegative) ((endTime?.time ?: ZERO) - (startTime?.time ?: ZERO))
        else abs((endTime?.time ?: ZERO) - (startTime?.time ?: ZERO))
    }

    fun convertDateTimeWithAmPm(dateString: String?, format: String, timeZoneId: String? = null): String? {
        if (dateString.isNullOrEmpty()) return null
        return try {
            val parser = SimpleDateFormat(DATE_TIME_SEC_FORMAT, Locale.getDefault()).apply {
                timeZone = if (timeZoneId.isNullOrEmpty()) TimeZone.getDefault() else TimeZone.getTimeZone(timeZoneId)
            }
            val date = parser.parse(dateString)
            SimpleDateFormat(format, Locale.getDefault()).format(date ?: "")
        } catch (ex: Exception) {
            null
        }
    }
}