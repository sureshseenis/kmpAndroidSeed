/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.ui.utils.extensions

object TextUtility {

    fun joinString(separator: String, vararg items: String?): String {
        return items.filter { it?.isNotEmpty() ?: false }
            .joinToString(separator)
    }

    fun getShortUserName(name: String?): String {
        val splitNameLength = name?.split(WIDE_SPACE)
        val returnNameTwoChars = if ((splitNameLength?.size ?: ZERO_INDEX) >= TWO) {
            splitNameLength?.first()?.first().toString() + "" + splitNameLength?.last()?.first()
        } else {
            name?.first().toString() + "" + name?.get(ONE)
        }
        return returnNameTwoChars.uppercase()
    }

    private const val ZERO_INDEX = 0
    private const val ONE = 1
    private const val TWO = 2
    private const val WIDE_SPACE = " "
}