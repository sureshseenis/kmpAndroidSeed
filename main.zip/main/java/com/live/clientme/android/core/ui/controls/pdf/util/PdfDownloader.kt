/*
 * © 2020-25 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program ("Live Enterprise Employee Experience Interaction Suite"),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.ui.controls.pdf.util

import android.content.Context
import android.util.Log
import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.URL
import java.net.URLConnection

class PdfDownloader(
    coroutineScope: CoroutineScope,
    private val headers: HeaderData,
    private val url: String,
    private val listener: StatusListener,
    private val ioDispatcher: CoroutineDispatcher = Dispatchers.IO,
    val mainDispatcher: CoroutineDispatcher = Dispatchers.Main
) {

    interface StatusListener {
        fun getContext(): Context
        fun onDownloadStart()
        fun onDownloadProgress(currentBytes: Long, totalBytes: Long)
        fun onDownloadSuccess(absolutePath: String)
        fun onError(error: Throwable)
    }

    private var lastDownloadedFile: String? = null

    init {
        coroutineScope.launch { checkAndDownload(url) }
    }

    companion object {
        private const val MAX_RETRIES = 3 // Maximum number of retries
        private const val RETRY_DELAY = 2000L // Delay between retries in milliseconds
    }

    private fun getCachedFileName(url: String): String {
        return url.hashCode().toString() + ".pdf"
    }

    private fun clearPdfCache(exceptFileName: String? = null) {
        val cacheDir = listener.getContext().cacheDir
        val pdfFiles =
            cacheDir.listFiles { _, name -> name.endsWith(".pdf") && name != exceptFileName }
        pdfFiles?.forEach {file ->
            val isDeleted = file.delete()
            if (isDeleted) {
                Log.d("PdfDownloader", "Deleted file: ${file.name}")
            } else {
                Log.e("PdfDownloader", "Failed to delete file: ${file.name}")
            }
        }
    }

    private suspend fun checkAndDownload(downloadUrl: String) {
        val cachedFileName = getCachedFileName(downloadUrl)

        if (lastDownloadedFile != cachedFileName) {
            clearPdfCache(cachedFileName) // Clear previous cache if a new file is being accessed
        }

        val cachedFile = File(listener.getContext().cacheDir, cachedFileName)

        if (cachedFile.exists()) {
            listener.onDownloadSuccess(cachedFile.absolutePath)
        } else {
            download(downloadUrl, cachedFileName)
        }

        lastDownloadedFile = cachedFileName // Update the last downloaded file
    }

    private suspend fun download(downloadUrl: String, cachedFileName: String) {
        var retries = 0
        while (retries < MAX_RETRIES) {
            withContext(ioDispatcher) {
                try {
                    listener.onDownloadStart()
                    val tempFile = downloadFile(downloadUrl)
                    validateAndSaveFile(tempFile, cachedFileName)
                    retries = MAX_RETRIES
                } catch (e: IOException) {
                    handleDownloadError(e, downloadUrl, retries)
                    retries++
                    if (retries < MAX_RETRIES) {
                        delay(RETRY_DELAY)
                    }
                }
            }
        }
    }

    private suspend fun downloadFile(downloadUrl: String): File {
        val cacheDir = listener.getContext().cacheDir
        val tempFile = withContext(ioDispatcher) {
            File.createTempFile("download_", ".tmp", cacheDir)
        }
        val urlConnection = withContext(ioDispatcher) {
            URL(downloadUrl).openConnection()
        }.apply {
            headers.headers.forEach { (key, value) -> setRequestProperty(key, value) }
        }
        val totalLength = getTotalLength(urlConnection)
        BufferedInputStream(withContext(ioDispatcher) {
            urlConnection.getInputStream()
        }).use { inputStream ->
            FileOutputStream(tempFile).use { outputStream ->
                val data = ByteArray(8192)
                var totalBytesRead = 0L
                var bytesRead: Int
                while (inputStream.read(data).also { bytesRead = it } != -1) {
                    outputStream.write(data, 0, bytesRead)
                    totalBytesRead += bytesRead
                    withContext(mainDispatcher) {
                        listener.onDownloadProgress(totalBytesRead, totalLength)
                    }
                }
                outputStream.flush()
            }
        }
        return tempFile
    }

    private fun getTotalLength(urlConnection: URLConnection): Long {
        return try {
            urlConnection.contentLengthLong
        } catch (e: NoSuchMethodError) {
            urlConnection.contentLength.toLong()
        }
    }

    private suspend fun validateAndSaveFile(tempFile: File, cachedFileName: String) {
        val cacheDir = listener.getContext().cacheDir
        if (tempFile.length() == getTotalLength(withContext(ioDispatcher) {
                URL(url).openConnection()
            })) {
            val outputFile = File(cacheDir, cachedFileName)
            val isRenamed = tempFile.renameTo(outputFile)
            if (isRenamed) {
                withContext(mainDispatcher) { listener.onDownloadSuccess(outputFile.absolutePath) }
            } else {
                throw IOException("Failed to rename temp file to $cachedFileName")
            }
        } else {
            throw IOException("Incomplete download")
        }
    }

    private suspend fun handleDownloadError(e: IOException, downloadUrl: String, retries: Int) {
        Log.e("PdfDownloader", "Download incomplete or failed: $downloadUrl", e)
        withContext(mainDispatcher) { listener.onError(e) }
        if (retries < MAX_RETRIES) {
            Log.d("PdfDownloader", "Retrying download: $downloadUrl. Attempt $retries")
        } else {
            withContext(mainDispatcher) {
                listener.onError(
                    IOException(
                        "Failed to download after $MAX_RETRIES attempts: $downloadUrl",
                        e
                    )
                )
            }
        }
    }
}