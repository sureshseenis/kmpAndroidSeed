/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.services.models

import com.live.clientme.android.core.domain.ErrorCodes
import com.live.clientme.android.core.services.fromJson
import retrofit2.HttpException
import java.net.SocketTimeoutException
import java.net.UnknownHostException

object ErrorResponseHandler {

    fun getErrorResponse(throwable: Throwable): ErrorResponse {
        val serviceErrorData = ErrorResponse()
        when (throwable) {
            is UnknownHostException, is SocketTimeoutException -> {
                serviceErrorData.errorCode = ErrorCodes.Base.NETWORK_ERROR
                serviceErrorData.message = throwable.message
            }
            is HttpException -> {
                val errorResponse = convertErrorBody(throwable)
                if (errorResponse != null) {
                    serviceErrorData.errorCode = errorResponse.errorCode
                    serviceErrorData.message = errorResponse.message
                } else {
                    serviceErrorData.errorCode = throwable.code().toString()
                    serviceErrorData.message = throwable.message()
                }
            }
        }
        // TODO: log the exception here :- added on 18/06/21 by emil.markose
        return serviceErrorData

    }

    private fun convertErrorBody(httpException: HttpException): ErrorResponse? {
        return try {
            val message = httpException.response()?.errorBody()?.string()
            val errorBody = message?.fromJson<BaseResponse>()
            errorBody?.errorMessage
        } catch (exception: Exception) {
            // TODO: add logger :- added on 18/06/21 by emil.markose
            null
        }
    }
}