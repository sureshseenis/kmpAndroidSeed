/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.ui.dialog

import android.app.Dialog
import android.content.Context
import android.util.TypedValue
import com.live.clientme.android.core.R

/**
 *
 * Base class for customizable dialog window.
 */
open class BaseDialog : Dialog {

    constructor (context: Context) : this(
        context, TypedValue()
    )

    private constructor (context: Context, typedValue: TypedValue) : this(
        context,
        typedValue,
        context.theme.resolveAttribute(R.attr.material_dialog_style, typedValue, true)
    )

    private constructor (context: Context, typedValue: TypedValue, boolean: Boolean) : this(
        context,
        typedValue.resourceId
    )

    private constructor(context: Context, themeResId: Int) : super(context, themeResId)
}