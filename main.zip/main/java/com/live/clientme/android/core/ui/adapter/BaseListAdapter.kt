/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program ("Live Enterprise Employee Experience Interaction Suite"),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.ViewDataBinding
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView


abstract class BaseListAdapter<T : ViewDataBinding, E : Distinct> :
    ListAdapter<E, BaseListViewHolder<T>>(BaseDiffCallback()) {

    /**
     * Override and implement this method to return the binding class of your item layout.
     */
    abstract fun getView(inflater: LayoutInflater, parent: ViewGroup, viewType: Int): T

    /**
     * Override and implement this method to bind your data model to the viewBinding class
     */
    abstract fun bind(holder: BaseListViewHolder<T>, item: E, position: Int)


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseListViewHolder<T> {
        return BaseListViewHolder(getView(LayoutInflater.from(parent.context), parent, viewType))
    }

    override fun onBindViewHolder(holder: BaseListViewHolder<T>, position: Int) {
        val item = getItem(position)
        bind(holder, item, position)
    }

    override fun onBindViewHolder(
        holder: BaseListViewHolder<T>,
        position: Int,
        payloads: MutableList<Any>
    ) {
        super.onBindViewHolder(holder, position, payloads)
        holder.binding.executePendingBindings()
    }

    private class BaseDiffCallback<DataModel : Distinct> : DiffUtil.ItemCallback<DataModel>() {

        override fun areItemsTheSame(oldItem: DataModel, newItem: DataModel): Boolean {
            return oldItem.getUniqueId() == newItem.getUniqueId()
        }

        override fun areContentsTheSame(oldItem: DataModel, newItem: DataModel): Boolean {
            return oldItem.toString() == newItem.toString()
        }
    }

    fun updateItems(items: List<E>) {
        submitList(items)
    }

    fun notifyChanges() {
        notifyItemRangeChanged(0, itemCount, arrayOf("partial_data_change"))
    }

}


interface Distinct {
    fun getUniqueId(): String
}

class BaseListViewHolder<T : ViewDataBinding>(val binding: T) :
    RecyclerView.ViewHolder(binding.root)