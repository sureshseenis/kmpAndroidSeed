/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program ("Live Enterprise Employee Experience Interaction Suite"),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */
package com.live.clientme.android.core.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.databinding.ViewDataBinding
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView

/**
 * A recyclerview adapter base class to avoid boiler plate code when writing adapter class for RecyclerViews.
 * Extend this class to your Custom adapter class and implement [getView] and [bind] methods.
 *
 * ```
 * class PhotoAdapter : ViewBindingAdapter<ItemPhotosBinding, ImagesModel>() {
 *
 *     override fun getView(inflater: LayoutInflater, parent: ViewGroup, viewType: Int) =
 *         ItemPhotosBinding.inflate(inflater, parent, false)
 *
 *     override fun bind(binding: ItemPhotosBinding, item: ImagesModel) {
 *         setPic(binding.imageView2, item.path)
 *     }
 *
 *     private fun setPic(imageView: ImageView, path: String) {
 *         imageView.loadImage(url = path, roundedCorners = true)
 *     }
 * }
 * ```
 *
 * @param [T] is the type of your binding class of your item.
 * @param [E] is the type of the data model.
 *
 * @property onItemClick to add click listeners to your root view.
 *
 */
abstract class BaseRecyclerViewAdapter<T : ViewDataBinding, E> :
    RecyclerView.Adapter<BaseRecyclerViewAdapter<T, E>.BaseVh>() {

    var loadedList = ArrayList<E>()
    var onItemClick: ((E, Int) -> Unit?)? = null

    /**
     * Override and implement this method to return the binding class of your item layout.
     */
    abstract fun getView(inflater: LayoutInflater, parent: ViewGroup, viewType: Int): T

    /**
     * Override and implement this method to bind your data model to the viewBinding class
     */
    abstract fun bind(binding: T, item: E, position: Int)

    /**
     * Call this method to update your dataset
     */
    fun updateItems(updatedList: List<E>) {
        val result = DiffUtil.calculateDiff(
            DiffCallback(this.loadedList, updatedList), false
        )
        this.loadedList = if (updatedList.isEmpty()) arrayListOf() else updatedList as ArrayList<E>
        result.dispatchUpdatesTo(this)
    }

    fun updateListItems(items: List<E>) {
        loadedList.clear()
        loadedList.addAll(items)
        notifyDataSetChanged()
    }

    fun notifyChanges() {
        notifyItemRangeChanged(0, loadedList.size, arrayOf("partial_data_change"))
    }

    final override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): BaseVh {
        val inflater = LayoutInflater.from(parent.context)
        return BaseVh(getView(inflater, parent, viewType))
    }

    final override fun onBindViewHolder(holder: BaseVh, position: Int) {
        val binding = holder.binding
        val item = loadedList[position]
        binding.root.setOnClickListener { onItemClick?.invoke(item, position) }
        bind(binding, item, position)
    }

    override fun getItemCount() = loadedList.size

    override fun onBindViewHolder(holder: BaseVh, position: Int, payloads: MutableList<Any>) {
        super.onBindViewHolder(holder, position, payloads)
        holder.binding.executePendingBindings()
    }

    inner class DiffCallback(
        private val oldList: List<E>, private val newList: List<E>
    ) : DiffUtil.Callback() {

        override fun getOldListSize(): Int {
            return oldList.size
        }

        override fun getNewListSize(): Int {
            return newList.size
        }

        override fun areItemsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
            return oldList[oldItemPosition] == newList[newItemPosition]
        }

        override fun areContentsTheSame(oldItemPosition: Int, newItemPosition: Int): Boolean {
            return oldList[oldItemPosition].hashCode().toString() ===
                    newList[newItemPosition].hashCode().toString()
        }

        override fun getChangePayload(oldItemPosition: Int, newItemPosition: Int): Boolean {
            return oldList[oldItemPosition].hashCode().toString() !==
                    newList[newItemPosition].hashCode().toString()
        }
    }

    inner class BaseVh(val binding: T) : RecyclerView.ViewHolder(binding.root)
}