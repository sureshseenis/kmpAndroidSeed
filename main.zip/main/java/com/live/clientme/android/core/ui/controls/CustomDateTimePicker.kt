/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.ui.controls

import android.content.Context
import android.graphics.Typeface
import android.util.AttributeSet
import android.view.LayoutInflater
import androidx.constraintlayout.widget.ConstraintLayout
import com.live.clientme.android.core.R
import com.live.clientme.android.core.databinding.LayoutDateTimePickerBinding
import com.shawnlin.numberpicker.NumberPicker
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*

class CustomDateTimePicker(context: Context, attrs: AttributeSet) :
    ConstraintLayout(context, attrs) {
    private lateinit var binding: LayoutDateTimePickerBinding

    init {
        init(context)
    }

    private fun init(context: Context?) {
        val inflater = LayoutInflater.from(context)
        binding = LayoutDateTimePickerBinding.inflate(inflater, this, true)
    }

    fun setDateTimePickerModel(model: DateTimePickerModel) {
        model.calculateTodayStartTimes()
        model.calculateDates(context)
        model.calculateTodayEndTimes()
        model.setUpDateAndTimePicker(binding)
        model.setUpTodayTimePickers(binding)
        binding.model = model
        binding.executePendingBindings()
    }
}

class DateTimePickerModel {
    private val timeFormatted = SimpleDateFormat(DEFAULT_TIME_FORMAT, Locale.US)
    private val dayFormatter = SimpleDateFormat(DATE_PICKER_DAY_FORMAT, Locale.US)
    private val dateList = mutableListOf<String>()
    private val dateMillisList = mutableListOf<Long>()
    private val endTimeList = mutableListOf<String>()
    private val startTimeList = mutableListOf<String>()
    private var startValue = 0
    private var endValue = 0
    private var selectedDate = ""
    private var selectedStartTime = ""
    private var selectedEndTime = ""
    private var isRecalculateRequired = true
    private var dateInMillis: Long = 0

    fun setUpDateAndTimePicker(binding: LayoutDateTimePickerBinding) {
        binding.apply {
            val dateValues = dateList.toList().toTypedArray()
            npStartTimePicker.setSelectedTypeface(Typeface.DEFAULT_BOLD)
            npEndTimePicker.setSelectedTypeface(Typeface.DEFAULT_BOLD)
            if (dateList.size > 2) {
                selectedDate = dateList[2]
            }
            if (dateMillisList.size > 2) {
                dateInMillis = dateMillisList[2]
            }
            calculateTodayStartTimes()
            calculateTodayEndTimes()
            npDatePicker.apply {
                setSelectedTypeface(Typeface.DEFAULT_BOLD)
                maxValue = dateList.size - 1
                displayedValues = dateValues

                setOnValueChangedListener { picker, _, selectedDatePosition ->
                    updateDateTimePickerData(selectedDatePosition, picker, binding)
                }
            }
        }
    }

    private fun updateDateTimePickerData(
        selectedDatePosition: Int,
        picker: NumberPicker,
        binding: LayoutDateTimePickerBinding
    ) {
        when (selectedDatePosition) {
            0, 1, 2 -> {
                CoroutineScope(Dispatchers.Default).launch {
                    delay(700)
                    picker.value = 2
                    if (dateList.size > 2) {
                        selectedDate = dateList[2]
                    }
                    if (dateMillisList.size > 2) {
                        dateInMillis = dateMillisList[2]
                    }
                }
                startTimeList.clear()
                endTimeList.clear()
                calculateTodayStartTimes()
                calculateTodayEndTimes()
                setUpTodayTimePickers(binding)
                isRecalculateRequired = true
            }

            else -> {
                selectedDate = dateList[selectedDatePosition]
                dateInMillis = dateMillisList[selectedDatePosition]
                if (isRecalculateRequired) {
                    startTimeList.clear()
                    endTimeList.clear()
                    calculateTimes()
                    setUpOtherDatesTimePickers(binding)
                    isRecalculateRequired = false
                }
            }
        }
    }

    fun setUpTodayTimePickers(binding: LayoutDateTimePickerBinding) {
        val endTimeValues = endTimeList.toList().toTypedArray()
        val startTimeValues = startTimeList.toList().toTypedArray()
        binding.apply {
            updateTodayEndTimepicker(endTimeValues)
            updateTodayStartTimepicker(startTimeValues)
        }
    }

    fun LayoutDateTimePickerBinding.updateTodayStartTimepicker(
        startTimeValues: Array<String>
    ) {
        this.npStartTimePicker.apply {
            (Typeface.DEFAULT_BOLD)
            maxValue = startTimeList.size - 1
            displayedValues = startTimeValues
            if (startTimeList.size > 3) {
                selectedStartTime = startTimeList[2]
            }
            setOnValueChangedListener { picker, _, newVal ->
                when (newVal) {
                    0, 1 -> {
                        CoroutineScope(Dispatchers.Default).launch {
                            delay(700)
                            picker.value = 2
                            startValue = 2
                        }
                        selectedStartTime = startTimeList[2]
                    }

                    else -> {
                        startValue = newVal
                        selectedStartTime = startTimeList[newVal]
                    }
                }
                if (startValue - endValue > 2) {
                    CoroutineScope(Dispatchers.Default).launch {
                        delay(700)
                        npEndTimePicker.value = startValue - 1
                        selectedEndTime = endTimeList[startValue - 1]
                    }
                }
            }
        }
    }

    fun LayoutDateTimePickerBinding.updateTodayEndTimepicker(
        endTimeValues: Array<String>
    ) {
        this.npEndTimePicker.apply {
            maxValue = endTimeList.size - 1
            displayedValues = endTimeValues
            if (endTimeList.size > 2) {
                selectedEndTime = endTimeList[2]
            }
            setOnValueChangedListener { _, _, newVal ->
                endValue = newVal
                if (startValue - endValue > 1) {
                    CoroutineScope(Dispatchers.Default).launch {
                        delay(700)
                        npEndTimePicker.value = startValue - 1
                        selectedEndTime = endTimeList[startValue - 1]
                    }
                }
                selectedEndTime = endTimeList[newVal]
            }
        }
    }

    fun setUpOtherDatesTimePickers(binding: LayoutDateTimePickerBinding) {
        val endTimeValues = endTimeList.toList().toTypedArray()
        val startTimeValues = startTimeList.toList().toTypedArray()
        binding.apply {

            npEndTimePicker.apply {
                maxValue = endTimeList.size - 1
                displayedValues = endTimeValues
                value = 3
                selectedEndTime = endTimeList[value]

                setOnValueChangedListener { _, _, newVal ->
                    endValue = newVal
                    if (startValue - endValue >= 0) {
                        CoroutineScope(Dispatchers.Default).launch {
                            delay(700)
                            npEndTimePicker.value = startValue + 1
                            selectedEndTime = endTimeList[startValue + 1]
                        }
                    }
                    selectedEndTime = endTimeList[newVal]
                }
            }

            npStartTimePicker.apply {
                maxValue = startTimeList.size - 1
                displayedValues = startTimeValues
                value = 2
                selectedStartTime = startTimeList[value]
                setOnValueChangedListener { _, _, newVal ->
                    startValue = newVal
                    selectedStartTime = startTimeList[newVal]
                    if (startValue - endValue >= 0) {
                        CoroutineScope(Dispatchers.Default).launch {
                            delay(700)
                            npEndTimePicker.value = startValue + 1
                            selectedEndTime = endTimeList[startValue + 1]
                        }
                    }
                }
            }
        }
    }

    fun calculateDates(context: Context) {
        val calendar = Calendar.getInstance()
        for (dateCount in -2..20) {
            val todayDate = calendar.get(Calendar.DAY_OF_MONTH)
            calendar.add(Calendar.DAY_OF_MONTH, dateCount)
            val date = calendar.get(Calendar.DAY_OF_MONTH)
            val formatter =
                SimpleDateFormat(DATE_DD_MMM_YYYY, Locale.US)
            val dateInMillis = convertTimeToMillis(
                formatter.format(Date(calendar.timeInMillis)),
                DATE_DD_MMM_YYYY
            )
            val formattedDate = dayFormatter.format(calendar.timeInMillis)

            val dateString = when (date) {
                todayDate -> {
                    context.getString(R.string.label_date_picker_today)
                }

                1, 21, 31 -> {
                    StringBuilder(formattedDate).append(context.getString(R.string.label_date_append_st))
                        .toString()
                }

                2, 22 -> {
                    StringBuilder(formattedDate).append(context.getString(R.string.label_date_append_nd))
                        .toString()
                }

                3, 23 -> {
                    StringBuilder(formattedDate).append(context.getString(R.string.label_date_append_rd))
                        .toString()
                }

                else -> {
                    StringBuilder(formattedDate).append(context.getString(R.string.label_date_append_th))
                        .toString()
                }
            }
            dateList.add(dateString)
            dateMillisList.add(dateInMillis)
            calendar.add(Calendar.DAY_OF_MONTH, -dateCount)
        }
    }

    private fun calculateTimes() {
        val date = Date()
        val calendar = Calendar.getInstance()
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        calendar.time = date
        calendar.set(Calendar.HOUR_OF_DAY, 0)
        calendar.set(Calendar.MINUTE, 0)

        while (day == calendar.get(Calendar.DAY_OF_MONTH)) {
            val unRoundedMinutes = calendar[Calendar.MINUTE]
            val mod = unRoundedMinutes % 15
            calendar.add(Calendar.MINUTE, -mod)

            val currentTimeFormatted = timeFormatted.format(calendar.time)
            val listTime = dropFirstZero(currentTimeFormatted)

            endTimeList.add(listTime)
            startTimeList.add(listTime)
            calendar.add(Calendar.MINUTE, 15)
        }
    }

    fun calculateTodayEndTimes() {
        val date = Date()
        val calendar = Calendar.getInstance()
        calendar.time = date

        val today = calendar.get(Calendar.DAY_OF_MONTH)

        while (today == calendar.get(Calendar.DAY_OF_MONTH)) {
            val unRoundedMinutes = calendar[Calendar.MINUTE]
            val mod = unRoundedMinutes % 15
            calendar.add(Calendar.MINUTE, -mod)

            val currentTimeFormatted = timeFormatted.format(calendar.time)
            val listTime = dropFirstZero(currentTimeFormatted)

            endTimeList.add(listTime)
            calendar.add(Calendar.MINUTE, 15)
        }
        startTimeList.addAll(endTimeList)
    }

    fun calculateTodayStartTimes() {
        val date = Date()
        val calendar = Calendar.getInstance()
        calendar.time = date
        val unRoundedMinutes = calendar[Calendar.MINUTE]
        val mod = unRoundedMinutes % 15
        calendar.add(Calendar.MINUTE, -mod)

        calendar.add(Calendar.MINUTE, -30)
        val listTime = dropFirstZero(timeFormatted.format(calendar.time))
        startTimeList.add(listTime)
        calendar.add(Calendar.MINUTE, 30)

        calendar.add(Calendar.MINUTE, -15)
        val secondListTime = dropFirstZero(timeFormatted.format(calendar.time))
        startTimeList.add(secondListTime)
    }

    private fun dropFirstZero(formattedTime: String): String {
        return when (formattedTime.startsWith("0")) {
            true -> formattedTime.drop(1)
            false -> formattedTime
        }
    }

    fun getSelectedDate(): String {
        return selectedDate
    }

    fun getSelectedStartTime(): String {
        return selectedStartTime
    }

    fun getSelectedStartTimeMillis(): Long {
        return getDateTimeInMillis(selectedStartTime)
    }

    fun getSelectedEndTimeMillis(): Long {
        return getDateTimeInMillis(selectedEndTime)
    }

    fun getDuration(): String {
        val duration =
            (getDateTimeInMillis(selectedEndTime) - getDateTimeInMillis(selectedStartTime)) / 60000
        return duration.toString()
    }

    fun getSelectedEndTime(): String {
        return selectedEndTime
    }

    companion object {
        const val DEFAULT_TIME_FORMAT = "HH:mm"
        const val DATE_PICKER_DAY_FORMAT = "EEE dd"
        const val DATE_DD_MMM_YYYY = "dd MMM yyyy"
    }

    fun convertTimeToMillis(time: String, dateFormat: String): Long {
        val format = SimpleDateFormat(dateFormat, Locale.getDefault())
        try {
            val date = format.parse(time)
            return date?.time ?: 0
        } catch (e: ParseException) {
            e.printStackTrace()
        }
        return 0
    }

    fun getDateTimeInMillis(time: String): Long {
        val calendar = Calendar.getInstance()
        calendar.timeInMillis = dateInMillis
        val timeCalendar = Calendar.getInstance()
        timeCalendar.timeInMillis = convertTimeToMillis(time, DEFAULT_TIME_FORMAT)
        calendar.set(Calendar.HOUR_OF_DAY, timeCalendar.get(Calendar.HOUR_OF_DAY))
        calendar.set(Calendar.MINUTE, timeCalendar.get(Calendar.MINUTE))
        return calendar.timeInMillis
    }
}