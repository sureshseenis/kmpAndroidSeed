/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.auth

import android.content.Context
import kotlinx.coroutines.runBlocking
import org.junit.Assert
import org.junit.Before
import org.junit.Test
import org.mockito.Mock
import org.mockito.Mockito
import org.mockito.MockitoAnnotations
import org.mockito.Spy
import org.mockito.kotlin.argumentCaptor
import org.mockito.kotlin.eq
import org.mockito.kotlin.times
import org.mockito.kotlin.verify

class MsalAuthManagerTests {

    @Mock
    lateinit var context: Context

    @Mock
    private lateinit var manager: MsalAuthManager

    @Spy
    private lateinit var controller: MsalAuthInteractorImpl

    @Before
    fun setup() {
        MockitoAnnotations.openMocks(this)
    }

    @Test
    fun verifyControllerGetInstance() {
        val controller: MsalAuthInteractorImpl = MsalAuthInteractorImpl.getInstance()
        Assert.assertNotNull(controller)
    }

    @Test
    fun verifyManagerGetInstance() {
        val manager: MsalAuthManager = MsalAuthManager.getInstance()
        Assert.assertNotNull(manager)
    }

    @Test
    fun `msal auth manager should call manager's initMsalClient once while calling instantiateMsal`() {
        runBlocking {
            controller.msalManager = manager
            controller.instantiateMsal(context)
            verify(manager, times(1)).initMsalClient(eq(context))
        }
    }

    @Test
    fun `msal auth manager should call manager's getSilentToken once while calling getSilentToken`() {
        controller.msalManager = manager
        controller.getSilentToken(context)
        verify(manager, times(1)).getSilentToken(eq(context))
    }

    @Test
    fun `msal auth manager should call getSilentToken once while calling loginWithMsal`() {
        Mockito.doReturn(AuthResponse()).`when`(manager).getSilentToken(context)
        controller.msalManager = manager
        val callback: (AuthResponse?) -> Unit = {}
        controller.loginWithMsal(context, callback)
        verify(manager, times(1)).getSilentToken(eq(context))
    }

    @Test
    fun `msal auth manager should call logout when user signs out`() = runBlocking {
        controller.msalManager = manager
        val callback: (Boolean, Exception?) -> Unit = { _, _ -> }
        val argumentCaptor = argumentCaptor<(Boolean, Exception?) -> Unit>()
        controller.logout(context, callback)
        verify(manager, times(1)).logout(eq(context), argumentCaptor.capture())
    }

}