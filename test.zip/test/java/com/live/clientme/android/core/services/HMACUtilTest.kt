/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.services

import android.content.Context
import android.os.Build.VERSION
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.ExperimentalCoroutinesApi
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.mockito.Mock
import org.mockito.junit.MockitoJUnitRunner
import java.lang.reflect.Field
import java.lang.reflect.Modifier
import java.sql.Timestamp

@ExperimentalCoroutinesApi
@RunWith(MockitoJUnitRunner::class)
class HMACUtilTest {

    private val sdkNameKey = "SDK_INT"
    private val defaultSdkVersion = 0
    private val newSdkVersion = 26
    private val apiKey = "A13wrRTUJHcUGQSHR+L3H123JyPlQpCgps102abhci="
    private val requestURI = "/api/techbar/appointments/test"
    private val requestBody = "Test HMAC request body"
    private val requestMethod = "POST"
    private val requestNonce = "46f4a288b8334ad8d070b871290c311b"
    private val requestTimeStamp = "1622714251"
    private val authType = "HMAC"
    private val appId = ""
    private val expectedHMACKey =
        "$authType ${appId}:krTCD6oOyOIauWRaJLOnxdwScQRH8iWijCWSUaJSpE8=:$requestNonce:$requestTimeStamp"
    private val expectedMd5 = "e2cd0246ec4f69da2db0336648cf9055"

    @Mock
    @ApplicationContext
    lateinit var context: Context

    @Before
    fun setUp() {
        setSdkVersion(VERSION::class.java.getField(sdkNameKey), newSdkVersion)
    }

    @Test
    fun isHMACKeyValid() {
        val actualHMACKey = HMACUtil.getHMACKey(
            apiKey,
            requestURI,
            requestBody,
            requestMethod,
            requestNonce,
            requestTimeStamp
        )
        assertEquals(expectedHMACKey, actualHMACKey)
    }

    @Test
    fun isHMACKeyNotNull() {
        val actualHMACKey = HMACUtil.getHMACKey(
            apiKey,
            requestURI,
            requestBody,
            requestMethod,
            requestNonce,
            requestTimeStamp
        )
        assertNotNull(actualHMACKey)
    }

    @Test
    fun isMd5Valid() {
        val actualMd5 = HMACUtil.getMd5(requestBody)
        assertEquals(expectedMd5, actualMd5)
    }

    @Test
    fun isMd5NotNull() {
        val actualMd5 = HMACUtil.getMd5(requestBody)
        assertNotNull(actualMd5)
    }

    private fun setSdkVersion(sdkVersionNameKey: Field, newBuildSdkVersion: Int) {
        sdkVersionNameKey.isAccessible = true
        val modifiersField = Field::class.java.getDeclaredField("modifiers")
        modifiersField.isAccessible = true
        modifiersField.setInt(
            sdkVersionNameKey,
            sdkVersionNameKey.modifiers and Modifier.FINAL.inv()
        )
        sdkVersionNameKey[null] = newBuildSdkVersion
    }

    @After
    fun tearDown() {
        setSdkVersion(VERSION::class.java.getField(sdkNameKey), defaultSdkVersion)
    }

    @Test
    fun getCurrentTimeStampDefaultVersion() {
        setSdkVersion(VERSION::class.java.getField(sdkNameKey), defaultSdkVersion)
        val time = HMACUtil.getCurrentTimeStamp()
        assertEquals(time, Timestamp(System.currentTimeMillis() / 1000L).time.toString())
    }

    @Test
    fun getCurrentTimeStampCurrentVersion() {
        setSdkVersion(VERSION::class.java.getField(sdkNameKey), newSdkVersion)
        val time = HMACUtil.getCurrentTimeStamp()
        assertNotNull(time)
    }

    @Test
    fun generateNonceTest() {
        val nonce = HMACUtil.generateNonce()
        assertNotNull(nonce)
    }

    @Test
    fun convertBytesToHexTest() {
        val nonce = HMACUtil.generateNonce()
        val hexString = HMACUtil.convertBytesToHex(nonce)
        assertNotNull(hexString)
    }
}