/*
 * © 2021 Infosys Limited, Bangalore, India. All Rights Reserved.
 * Version:1.0.0.0
 *
 * Except for any free or open source software components
 * embedded in this Infosys proprietary software program (“Live Enterprise Employee Experience Interaction Suite”),
 * this Program is protected by copyright laws, international treaties
 * and other pending or existing intellectual property rights in India,
 * the United States and other countries. Except as expressly permitted,
 * any unauthorized reproduction, storage, transmission in any form or
 * by any means (including without limitation electronic, mechanical,
 * printing, photocopying, recording or otherwise), or any distribution
 * of this Program, or any portion of it, may result in severe civil and criminal
 * penalties, and will be prosecuted to the maximum extent possible under the law.
 */

package com.live.clientme.android.core.ui.utils

import org.junit.Test
import java.util.*

class DateTimeUtilityTest {

    @Test
    fun checkTimeLessThanMinAgo() {
        val calendar = Calendar.getInstance()
        calendar.add(Calendar.SECOND, 30)
        val result = DateTimeUtility.isTimeLessThanMinAgo(calendar.time.time)
        assert(result)
    }

    @Test
    fun checkTimeIsNotLessThanMinAgo() {
        val calendar = Calendar.getInstance()
        //set time one min ago
        calendar.add(Calendar.SECOND, -65)
        val result = DateTimeUtility.isTimeLessThanMinAgo(calendar.time.time)
        assert(!result)
    }
}